# Сборка ZeroGram APK

## Требования
- Java 17+
- Android SDK (compileSdk 34, minSdk 24)
- Gradle 8.5

## Сборка на GitHub Codespaces

1. Открой GitHub Codespaces или создай новый
2. Загрузи ZeroGram.zip и распакуй:
   ```
   unzip ZeroGram.zip
   cd ZeroGram/android
   ```
3. Установи Android SDK (если не установлен):
   ```
   sudo apt update
   sudo apt install -y default-jdk wget unzip
   export ANDROID_HOME=$HOME/android-sdk
   mkdir -p $ANDROID_HOME/cmdline-tools
   wget https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip -O cmdtools.zip
   unzip cmdtools.zip -d $ANDROID_HOME/cmdline-tools
   mv $ANDROID_HOME/cmdline-tools/cmdline-tools $ANDROID_HOME/cmdline-tools/latest
   export PATH=$PATH:$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools
   yes | sdkmanager "platforms;android-34" "build-tools;34.0.0"
   ```
4. Собери APK:
   ```
   chmod +x gradlew
   ./gradlew assembleDebug
   ```
5. APK будет в:
   ```
   app/build/outputs/apk/debug/app-debug.apk
   ```

## Примечание
- gradlew нужно создать через `gradle wrapper` если его нет
- Или используй `gradle assembleDebug` напрямую если Gradle установлен
