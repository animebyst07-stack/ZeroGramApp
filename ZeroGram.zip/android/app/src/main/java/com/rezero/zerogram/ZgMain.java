package com.rezero.zerogram;

import android.app.Activity;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.ConsoleMessage;
import android.webkit.CookieManager;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class ZgMain extends Activity {

    private WebView zgWebView;
    private long zgLastBackPress = 0;
    private static final long ZG_BACK_INTERVAL = 2000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestWindowFeature(Window.FEATURE_NO_TITLE);

        setupStatusBar();

        setContentView(com.rezero.zerogram.R.layout.zg_main);

        zgWebView = findViewById(com.rezero.zerogram.R.id.zg_webview);

        setupWebView();

        zgWebView.loadUrl("file:///android_asset/www/index.html");
    }

    private void setupStatusBar() {
        Window window = getWindow();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(Color.parseColor("#0f0f14"));
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            WindowManager.LayoutParams layoutParams = window.getAttributes();
            layoutParams.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            window.setAttributes(layoutParams);
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.setNavigationBarColor(Color.parseColor("#1a1a24"));
        }
    }

    private void setupWebView() {
        WebSettings settings = zgWebView.getSettings();

        settings.setJavaScriptEnabled(true);

        settings.setDomStorageEnabled(true);

        settings.setDatabaseEnabled(true);

        settings.setCacheMode(WebSettings.LOAD_DEFAULT);

        settings.setAllowFileAccess(true);

        settings.setAllowContentAccess(true);

        settings.setMediaPlaybackRequiresUserGesture(false);

        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);

        settings.setUseWideViewPort(true);

        settings.setLoadWithOverviewMode(true);

        settings.setSupportZoom(false);

        settings.setBuiltInZoomControls(false);

        settings.setDisplayZoomControls(false);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            settings.setSafeBrowsingEnabled(true);
        }

        settings.setUserAgentString(settings.getUserAgentString() + " ZeroGram/1.0");

        CookieManager cookieManager = CookieManager.getInstance();
        cookieManager.setAcceptCookie(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            cookieManager.setAcceptThirdPartyCookies(zgWebView, true);
        }

        zgWebView.setWebViewClient(new ZgWebViewClient());

        zgWebView.setWebChromeClient(new ZgChromeClient());

        zgWebView.setBackgroundColor(Color.parseColor("#0f0f14"));

        zgWebView.setOverScrollMode(View.OVER_SCROLL_NEVER);

        zgWebView.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            WebView.setWebContentsDebuggingEnabled(true);
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            if (zgWebView != null) {
                zgWebView.evaluateJavascript(
                    "(function() {" +
                    "  var hash = window.location.hash || '';" +
                    "  if (hash === '#accounts' || hash === '' || hash === '#') {" +
                    "    return 'EXIT';" +
                    "  } else if (hash.indexOf('#chat/') === 0) {" +
                    "    window.location.hash = '#chats';" +
                    "    return 'HANDLED';" +
                    "  } else if (hash === '#add-account') {" +
                    "    window.location.hash = '#accounts';" +
                    "    return 'HANDLED';" +
                    "  } else if (hash.indexOf('#acc-settings/') === 0) {" +
                    "    window.location.hash = '#accounts';" +
                    "    return 'HANDLED';" +
                    "  } else {" +
                    "    window.location.hash = '#accounts';" +
                    "    return 'HANDLED';" +
                    "  }" +
                    "})()",
                    value -> {
                        if (value != null && value.contains("EXIT")) {
                            runOnUiThread(() -> {
                                long now = System.currentTimeMillis();
                                if (now - zgLastBackPress < ZG_BACK_INTERVAL) {
                                    finish();
                                } else {
                                    zgLastBackPress = now;
                                    Toast.makeText(ZgMain.this,
                                        "Нажмите ещё раз для выхода",
                                        Toast.LENGTH_SHORT).show();
                                }
                            });
                        }
                    }
                );
                return true;
            }
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (zgWebView != null) {
            zgWebView.onResume();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (zgWebView != null) {
            zgWebView.onPause();
        }
    }

    @Override
    protected void onDestroy() {
        if (zgWebView != null) {
            zgWebView.evaluateJavascript(
                "if(typeof ZgTelegram!=='undefined'){ZgTelegram.Connection.disconnectAll();}",
                null
            );
            zgWebView.destroy();
        }
        super.onDestroy();
    }

    private class ZgWebViewClient extends WebViewClient {

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            String url = request.getUrl().toString();

            if (url.startsWith("file:///android_asset/")) {
                return false;
            }

            if (url.startsWith("https://") || url.startsWith("http://")) {
                return false;
            }

            return true;
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);

            view.evaluateJavascript(
                "document.documentElement.style.overscrollBehavior='none';" +
                "document.body.style.overscrollBehavior='none';",
                null
            );
        }
    }

    private class ZgChromeClient extends WebChromeClient {

        @Override
        public boolean onConsoleMessage(ConsoleMessage consoleMessage) {
            android.util.Log.d("ZeroGram",
                consoleMessage.message() +
                " -- line " + consoleMessage.lineNumber() +
                " of " + consoleMessage.sourceId());
            return true;
        }

        @Override
        public void onPermissionRequest(PermissionRequest request) {
            request.grant(request.getResources());
        }
    }
}
