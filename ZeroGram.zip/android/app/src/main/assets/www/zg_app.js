var ZgApp = (function() {
    'use strict';

    var Router = {
        _currentRoute: '',
        _currentParams: {},

        init: function() {
            var self = this;
            window.addEventListener('hashchange', function() {
                self._handleRoute();
            });
            this._handleRoute();
        },

        _handleRoute: function() {
            var hash = window.location.hash || '#accounts';
            var parts = hash.substring(1).split('/');
            var route = parts[0];
            var params = parts.slice(1);

            this._currentRoute = route;
            this._currentParams = params;

            this._updateNavigation(route);
            this._renderScreen(route, params);
        },

        _updateNavigation: function(route) {
            var navItems = document.querySelectorAll('.zg-nav-item');
            for (var i = 0; i < navItems.length; i++) {
                var navRoute = navItems[i].getAttribute('data-route');
                navItems[i].classList.toggle('zg-active', navRoute === route);
            }

            var backBtn = document.getElementById('zg-btn-back');
            var settingsBtn = document.getElementById('zg-btn-settings');
            var navBar = document.getElementById('zg-nav');

            var showBack = ['add-account', 'chat', 'acc-settings'].indexOf(route) !== -1;
            var showNav = ['accounts', 'chats', 'settings'].indexOf(route) !== -1;

            if (backBtn) {
                backBtn.classList.toggle('zg-hidden', !showBack);
            }
            if (navBar) {
                navBar.classList.toggle('zg-hidden', !showNav);
            }

            var content = document.getElementById('zg-content');
            if (content) {
                if (showNav) {
                    content.style.bottom = 'calc(var(--zg-nav-h) + var(--zg-safe-bottom))';
                } else if (route === 'chat') {
                    content.style.bottom = '0';
                } else {
                    content.style.bottom = '0';
                }
            }
        },

        _renderScreen: function(route, params) {
            var content = document.getElementById('zg-content');
            var headerTitle = document.getElementById('zg-header-title');
            var headerSub = document.getElementById('zg-header-sub');

            if (!content) return;

            var titles = {
                'accounts': 'ZeroGram',
                'chats': 'Чаты',
                'settings': 'Настройки',
                'add-account': 'Новый аккаунт',
                'acc-settings': 'Аккаунт'
            };

            switch (route) {
                case 'accounts':
                    if (headerTitle) headerTitle.textContent = titles[route];
                    if (headerSub) {
                        var count = ZgStorage.Accounts.getCount();
                        headerSub.textContent = count > 0 ? count + ' аккаунт(ов)' : 'Нет аккаунтов';
                    }
                    ZgUI.Screen.renderAccounts(content);
                    break;

                case 'chats':
                    if (headerTitle) {
                        var activeAcc = ZgStorage.Accounts.getActive();
                        headerTitle.textContent = activeAcc ? (activeAcc.firstName || activeAcc.username || 'Чаты') : 'Чаты';
                    }
                    if (headerSub) headerSub.textContent = '';
                    ZgUI.Screen.renderChats(content);
                    break;

                case 'chat':
                    var chatId = params[0];
                    var chatType = params[1] || 'user';
                    if (headerTitle) headerTitle.textContent = 'Чат';
                    if (headerSub) headerSub.textContent = '';
                    ZgUI.Screen.renderChat(content, chatId, chatType);
                    break;

                case 'settings':
                    if (headerTitle) headerTitle.textContent = titles[route];
                    if (headerSub) headerSub.textContent = '';
                    ZgUI.Screen.renderSettings(content);
                    break;

                case 'add-account':
                    if (headerTitle) headerTitle.textContent = titles[route];
                    if (headerSub) headerSub.textContent = 'Подключение Telegram';
                    ZgUI.Screen.renderAddAccount(content);
                    break;

                case 'acc-settings':
                    var accId = params[0];
                    if (headerTitle) headerTitle.textContent = 'Аккаунт';
                    if (headerSub) headerSub.textContent = '';
                    ZgUI.Screen.renderAccountSettings(content, accId);
                    break;

                default:
                    window.location.hash = '#accounts';
                    break;
            }
        },

        getCurrentRoute: function() {
            return this._currentRoute;
        },

        navigate: function(route) {
            window.location.hash = '#' + route;
        }
    };

    var AppController = {

        _initialized: false,

        init: function() {
            if (this._initialized) return;
            this._initialized = true;

            console.log('[ZgApp] Инициализация ZeroGram v1.0.0');
            console.log('[ZgApp] GramJS загружен:', ZgTelegram.isGramJSLoaded());

            ZgGroq.init();
            ZgTelegram.Notifications.init();

            this._setupBackButton();
            this._setupSettingsButton();
            this._setupNavigation();

            this._showSplash(function() {
                AppController._showApp();

                var accounts = ZgStorage.Accounts.getAll();
                if (accounts.length > 0 && ZgTelegram.isGramJSLoaded()) {
                    console.log('[ZgApp] Восстановление сессий...');
                    ZgTelegram.Session.restoreAllSessions(function(result) {
                        if (result.results) {
                            var connected = 0;
                            for (var i = 0; i < result.results.length; i++) {
                                if (result.results[i].success) connected++;
                            }
                            if (connected > 0) {
                                ZgUI.Toast.show('Подключено аккаунтов: ' + connected, 'success');
                            }
                        }
                    });
                }

                Router.init();
            });
        },

        _showSplash: function(callback) {
            setTimeout(function() {
                var splash = document.getElementById('zg-splash');
                if (splash) {
                    splash.style.transition = 'opacity 0.5s ease-out';
                    splash.style.opacity = '0';
                    setTimeout(function() {
                        splash.classList.add('zg-hidden');
                        callback();
                    }, 500);
                } else {
                    callback();
                }
            }, 2000);
        },

        _showApp: function() {
            var appContainer = document.getElementById('zg-app-container');
            if (appContainer) {
                appContainer.classList.remove('zg-hidden');
                appContainer.style.animation = 'zgFadeIn 0.3s ease-out';
            }
        },

        _setupBackButton: function() {
            var backBtn = document.getElementById('zg-btn-back');
            if (backBtn) {
                backBtn.addEventListener('click', function() {
                    var route = Router.getCurrentRoute();
                    if (route === 'chat') {
                        window.location.hash = '#chats';
                    } else if (route === 'acc-settings') {
                        window.location.hash = '#accounts';
                    } else if (route === 'add-account') {
                        ZgTelegram.Auth.cancelAuth();
                        if (window._zgAddAccountId) {
                            var acc = ZgStorage.Accounts.getById(window._zgAddAccountId);
                            if (acc && !acc.sessionString) {
                                ZgStorage.Accounts.remove(window._zgAddAccountId);
                            }
                        }
                        window.location.hash = '#accounts';
                    } else {
                        window.history.back();
                    }
                });
            }
        },

        _setupSettingsButton: function() {
            var settingsBtn = document.getElementById('zg-btn-settings');
            if (settingsBtn) {
                settingsBtn.addEventListener('click', function() {
                    window.location.hash = '#settings';
                });
            }
        },

        _setupNavigation: function() {
            var navItems = document.querySelectorAll('.zg-nav-item');
            for (var i = 0; i < navItems.length; i++) {
                navItems[i].addEventListener('click', function() {
                    var route = this.getAttribute('data-route');
                    if (route) {
                        Router.navigate(route);
                    }
                });
            }
        }
    };

    document.addEventListener('DOMContentLoaded', function() {
        AppController.init();
    });

    return {
        Router: Router,
        Controller: AppController
    };
})();
