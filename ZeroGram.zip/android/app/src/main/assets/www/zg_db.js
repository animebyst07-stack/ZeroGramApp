var ZgStorage = (function() {
    'use strict';

    var STORAGE_PREFIX = 'zg_';
    var ACCOUNTS_KEY = STORAGE_PREFIX + 'accounts';
    var SETTINGS_KEY = STORAGE_PREFIX + 'settings';
    var SESSIONS_KEY = STORAGE_PREFIX + 'sessions';
    var ACTIVE_ACC_KEY = STORAGE_PREFIX + 'active_acc';

    function _safeGet(key, fallback) {
        try {
            var raw = localStorage.getItem(key);
            if (raw === null || raw === undefined) {
                return fallback;
            }
            return JSON.parse(raw);
        } catch (err) {
            console.error('[ZgStorage] Ошибка чтения ' + key + ':', err);
            return fallback;
        }
    }

    function _safeSet(key, value) {
        try {
            localStorage.setItem(key, JSON.stringify(value));
            return true;
        } catch (err) {
            console.error('[ZgStorage] Ошибка записи ' + key + ':', err);
            return false;
        }
    }

    function _safeRemove(key) {
        try {
            localStorage.removeItem(key);
            return true;
        } catch (err) {
            console.error('[ZgStorage] Ошибка удаления ' + key + ':', err);
            return false;
        }
    }

    function _generateId() {
        var timestamp = Date.now().toString(36);
        var randomPart = Math.random().toString(36).substring(2, 8);
        return 'acc_' + timestamp + '_' + randomPart;
    }

    var AccountRepository = {

        getAll: function() {
            return _safeGet(ACCOUNTS_KEY, []);
        },

        getById: function(accountId) {
            var accounts = this.getAll();
            for (var i = 0; i < accounts.length; i++) {
                if (accounts[i].id === accountId) {
                    return accounts[i];
                }
            }
            return null;
        },

        add: function(accountData) {
            var accounts = this.getAll();
            var newAccount = {
                id: _generateId(),
                apiId: accountData.apiId,
                apiHash: accountData.apiHash,
                phone: accountData.phone || '',
                firstName: accountData.firstName || '',
                lastName: accountData.lastName || '',
                username: accountData.username || '',
                photoUrl: accountData.photoUrl || '',
                notificationsEnabled: true,
                createdAt: Date.now(),
                lastActiveAt: Date.now(),
                isConnected: false,
                sessionString: accountData.sessionString || ''
            };
            accounts.push(newAccount);
            _safeSet(ACCOUNTS_KEY, accounts);
            return newAccount;
        },

        update: function(accountId, updates) {
            var accounts = this.getAll();
            var found = false;
            for (var i = 0; i < accounts.length; i++) {
                if (accounts[i].id === accountId) {
                    var keys = Object.keys(updates);
                    for (var k = 0; k < keys.length; k++) {
                        accounts[i][keys[k]] = updates[keys[k]];
                    }
                    accounts[i].lastActiveAt = Date.now();
                    found = true;
                    break;
                }
            }
            if (found) {
                _safeSet(ACCOUNTS_KEY, accounts);
            }
            return found;
        },

        remove: function(accountId) {
            var accounts = this.getAll();
            var filtered = [];
            for (var i = 0; i < accounts.length; i++) {
                if (accounts[i].id !== accountId) {
                    filtered.push(accounts[i]);
                }
            }
            _safeSet(ACCOUNTS_KEY, filtered);
            SessionRepository.remove(accountId);
            var activeId = this.getActiveId();
            if (activeId === accountId) {
                if (filtered.length > 0) {
                    this.setActiveId(filtered[0].id);
                } else {
                    _safeRemove(ACTIVE_ACC_KEY);
                }
            }
            return true;
        },

        getCount: function() {
            return this.getAll().length;
        },

        getActiveId: function() {
            return _safeGet(ACTIVE_ACC_KEY, null);
        },

        setActiveId: function(accountId) {
            _safeSet(ACTIVE_ACC_KEY, accountId);
        },

        getActive: function() {
            var activeId = this.getActiveId();
            if (!activeId) {
                return null;
            }
            return this.getById(activeId);
        },

        setNotifications: function(accountId, enabled) {
            return this.update(accountId, { notificationsEnabled: enabled });
        },

        getNotificationStatus: function(accountId) {
            var account = this.getById(accountId);
            if (!account) {
                return true;
            }
            return account.notificationsEnabled;
        },

        setConnected: function(accountId, connected) {
            return this.update(accountId, { isConnected: connected });
        },

        updateSession: function(accountId, sessionString) {
            return this.update(accountId, { sessionString: sessionString });
        }
    };

    var SessionRepository = {

        get: function(accountId) {
            var sessions = _safeGet(SESSIONS_KEY, {});
            return sessions[accountId] || null;
        },

        save: function(accountId, sessionData) {
            var sessions = _safeGet(SESSIONS_KEY, {});
            sessions[accountId] = {
                data: sessionData,
                updatedAt: Date.now()
            };
            _safeSet(SESSIONS_KEY, sessions);
        },

        remove: function(accountId) {
            var sessions = _safeGet(SESSIONS_KEY, {});
            delete sessions[accountId];
            _safeSet(SESSIONS_KEY, sessions);
        },

        getAll: function() {
            return _safeGet(SESSIONS_KEY, {});
        },

        clear: function() {
            _safeSet(SESSIONS_KEY, {});
        }
    };

    var SettingsRepository = {

        getAll: function() {
            return _safeGet(SETTINGS_KEY, {
                groqApiKey: '',
                groqEnabled: false,
                groqModel: 'llama-3.3-70b-versatile',
                notificationsGlobal: true,
                theme: 'dark',
                fontSize: 'normal',
                language: 'ru',
                sendByEnter: true,
                showOnlineStatus: true,
                autoDownloadMedia: false
            });
        },

        get: function(key) {
            var settings = this.getAll();
            return settings[key];
        },

        set: function(key, value) {
            var settings = this.getAll();
            settings[key] = value;
            _safeSet(SETTINGS_KEY, settings);
        },

        setMultiple: function(updates) {
            var settings = this.getAll();
            var keys = Object.keys(updates);
            for (var i = 0; i < keys.length; i++) {
                settings[keys[i]] = updates[keys[i]];
            }
            _safeSet(SETTINGS_KEY, settings);
        },

        getGroqConfig: function() {
            var settings = this.getAll();
            return {
                apiKey: settings.groqApiKey || '',
                enabled: settings.groqEnabled || false,
                model: settings.groqModel || 'llama-3.3-70b-versatile'
            };
        },

        setGroqConfig: function(config) {
            this.setMultiple({
                groqApiKey: config.apiKey || '',
                groqEnabled: config.enabled || false,
                groqModel: config.model || 'llama-3.3-70b-versatile'
            });
        },

        reset: function() {
            _safeRemove(SETTINGS_KEY);
        }
    };

    var CacheManager = {

        _cachePrefix: STORAGE_PREFIX + 'cache_',

        set: function(key, value, ttlMs) {
            var cacheEntry = {
                value: value,
                expiresAt: ttlMs ? Date.now() + ttlMs : null
            };
            _safeSet(this._cachePrefix + key, cacheEntry);
        },

        get: function(key) {
            var entry = _safeGet(this._cachePrefix + key, null);
            if (!entry) {
                return null;
            }
            if (entry.expiresAt && Date.now() > entry.expiresAt) {
                _safeRemove(this._cachePrefix + key);
                return null;
            }
            return entry.value;
        },

        remove: function(key) {
            _safeRemove(this._cachePrefix + key);
        },

        clearAll: function() {
            var keysToRemove = [];
            for (var i = 0; i < localStorage.length; i++) {
                var k = localStorage.key(i);
                if (k && k.indexOf(this._cachePrefix) === 0) {
                    keysToRemove.push(k);
                }
            }
            for (var j = 0; j < keysToRemove.length; j++) {
                localStorage.removeItem(keysToRemove[j]);
            }
        }
    };

    function clearAllData() {
        var keysToRemove = [];
        for (var i = 0; i < localStorage.length; i++) {
            var key = localStorage.key(i);
            if (key && key.indexOf(STORAGE_PREFIX) === 0) {
                keysToRemove.push(key);
            }
        }
        for (var j = 0; j < keysToRemove.length; j++) {
            localStorage.removeItem(keysToRemove[j]);
        }
    }

    function getStorageUsage() {
        var total = 0;
        for (var i = 0; i < localStorage.length; i++) {
            var key = localStorage.key(i);
            if (key && key.indexOf(STORAGE_PREFIX) === 0) {
                var value = localStorage.getItem(key);
                total += key.length + (value ? value.length : 0);
            }
        }
        return {
            bytes: total * 2,
            formatted: _formatBytes(total * 2)
        };
    }

    function _formatBytes(bytes) {
        if (bytes === 0) return '0 Б';
        var units = ['Б', 'КБ', 'МБ', 'ГБ'];
        var i = Math.floor(Math.log(bytes) / Math.log(1024));
        return (bytes / Math.pow(1024, i)).toFixed(1) + ' ' + units[i];
    }

    function exportData() {
        var data = {
            accounts: AccountRepository.getAll(),
            sessions: SessionRepository.getAll(),
            settings: SettingsRepository.getAll(),
            exportedAt: Date.now(),
            version: '1.0.0'
        };
        return JSON.stringify(data, null, 2);
    }

    function importData(jsonString) {
        try {
            var data = JSON.parse(jsonString);
            if (data.accounts) {
                _safeSet(ACCOUNTS_KEY, data.accounts);
            }
            if (data.sessions) {
                _safeSet(SESSIONS_KEY, data.sessions);
            }
            if (data.settings) {
                _safeSet(SETTINGS_KEY, data.settings);
            }
            return { success: true };
        } catch (err) {
            return { success: false, error: err.message };
        }
    }

    return {
        Accounts: AccountRepository,
        Sessions: SessionRepository,
        Settings: SettingsRepository,
        Cache: CacheManager,
        clearAllData: clearAllData,
        getStorageUsage: getStorageUsage,
        exportData: exportData,
        importData: importData
    };
})();
