var ZgGroq = (function() {
    'use strict';

    var GROQ_API_URL = 'https://api.groq.com/openai/v1/chat/completions';

    var RESTRUCTURE_PROMPT = 'Rewrite the following text to improve its structure and clarity without changing the meaning. Focus only on organization, flow, and readability. Do not add new information, opinions, suggestions, or commentary. Preserve all original content but reorganize sentences and paragraphs if needed for logical order. Provide the rewritten text only, with no extra explanation: ';

    var GroqService = {

        _apiKey: '',
        _model: 'llama-3.3-70b-versatile',
        _enabled: false,
        _isProcessing: false,

        init: function() {
            var config = ZgStorage.Settings.getGroqConfig();
            this._apiKey = config.apiKey || '';
            this._model = config.model || 'llama-3.3-70b-versatile';
            this._enabled = config.enabled || false;
            console.log('[ZgGroq] Инициализация. Активен:', this._enabled);
        },

        isEnabled: function() {
            return this._enabled && this._apiKey.length > 0;
        },

        isProcessing: function() {
            return this._isProcessing;
        },

        setApiKey: function(key) {
            this._apiKey = key;
            ZgStorage.Settings.set('groqApiKey', key);
            if (key.length > 0) {
                this._enabled = true;
                ZgStorage.Settings.set('groqEnabled', true);
            }
        },

        setEnabled: function(enabled) {
            this._enabled = enabled;
            ZgStorage.Settings.set('groqEnabled', enabled);
        },

        setModel: function(model) {
            this._model = model;
            ZgStorage.Settings.set('groqModel', model);
        },

        getApiKey: function() {
            return this._apiKey;
        },

        getModel: function() {
            return this._model;
        },

        getAvailableModels: function() {
            return [
                {
                    id: 'llama-3.3-70b-versatile',
                    name: 'Llama 3.3 70B',
                    description: 'Лучшее качество, медленнее'
                },
                {
                    id: 'llama-3.1-8b-instant',
                    name: 'Llama 3.1 8B',
                    description: 'Быстрый, хорошее качество'
                },
                {
                    id: 'llama-3.2-3b-preview',
                    name: 'Llama 3.2 3B',
                    description: 'Самый быстрый'
                },
                {
                    id: 'gemma2-9b-it',
                    name: 'Gemma 2 9B',
                    description: 'Google, сбалансированный'
                },
                {
                    id: 'mixtral-8x7b-32768',
                    name: 'Mixtral 8x7B',
                    description: 'Mistral, длинный контекст'
                }
            ];
        },

        restructureText: function(text, callback) {
            if (!this.isEnabled()) {
                callback({ success: false, error: 'Groq не активен' });
                return;
            }

            if (!text || text.trim().length === 0) {
                callback({ success: false, error: 'Пустой текст' });
                return;
            }

            if (text.trim().length < 10) {
                callback({ success: true, text: text });
                return;
            }

            this._isProcessing = true;

            var requestBody = {
                model: this._model,
                messages: [
                    {
                        role: 'user',
                        content: RESTRUCTURE_PROMPT + text
                    }
                ],
                temperature: 0.3,
                max_tokens: 4096,
                top_p: 1,
                stream: false
            };

            var self = this;

            fetch(GROQ_API_URL, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'Bearer ' + this._apiKey
                },
                body: JSON.stringify(requestBody)
            })
            .then(function(response) {
                if (!response.ok) {
                    return response.json().then(function(errData) {
                        throw new Error(errData.error ? errData.error.message : 'HTTP ' + response.status);
                    });
                }
                return response.json();
            })
            .then(function(data) {
                self._isProcessing = false;
                if (data.choices && data.choices.length > 0 && data.choices[0].message) {
                    var restructuredText = data.choices[0].message.content;
                    restructuredText = restructuredText.trim();
                    callback({
                        success: true,
                        text: restructuredText,
                        usage: data.usage || null
                    });
                } else {
                    callback({
                        success: false,
                        error: 'Пустой ответ от Groq'
                    });
                }
            })
            .catch(function(error) {
                self._isProcessing = false;
                console.error('[ZgGroq] Ошибка:', error);
                callback({
                    success: false,
                    error: error.message || 'Ошибка соединения'
                });
            });
        },

        testConnection: function(callback) {
            if (!this._apiKey || this._apiKey.length === 0) {
                callback({ success: false, error: 'API ключ не указан' });
                return;
            }

            var requestBody = {
                model: this._model,
                messages: [
                    {
                        role: 'user',
                        content: 'Ответь одним словом: работает'
                    }
                ],
                temperature: 0,
                max_tokens: 10
            };

            fetch(GROQ_API_URL, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'Bearer ' + this._apiKey
                },
                body: JSON.stringify(requestBody)
            })
            .then(function(response) {
                if (!response.ok) {
                    return response.json().then(function(errData) {
                        throw new Error(errData.error ? errData.error.message : 'HTTP ' + response.status);
                    });
                }
                return response.json();
            })
            .then(function(data) {
                callback({ success: true, message: 'Подключение успешно' });
            })
            .catch(function(error) {
                callback({ success: false, error: error.message || 'Ошибка соединения' });
            });
        }
    };

    return GroqService;
})();
