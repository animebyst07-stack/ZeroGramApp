var ZgUI = (function() {
    'use strict';

    function _el(tag, className, attrs) {
        var element = document.createElement(tag);
        if (className) {
            element.className = className;
        }
        if (attrs) {
            var keys = Object.keys(attrs);
            for (var i = 0; i < keys.length; i++) {
                var key = keys[i];
                if (key === 'textContent') {
                    element.textContent = attrs[key];
                } else if (key === 'innerHTML') {
                    element.innerHTML = attrs[key];
                } else if (key === 'onclick') {
                    element.addEventListener('click', attrs[key]);
                } else {
                    element.setAttribute(key, attrs[key]);
                }
            }
        }
        return element;
    }

    function _svg(name) {
        var icons = {
            plus: '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>',
            send: '<svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor"><path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/></svg>',
            search: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>',
            bell: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 01-3.46 0"/></svg>',
            bellOff: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2"><path d="M13.73 21a2 2 0 01-3.46 0"/><path d="M18.63 13A17.89 17.89 0 0118 8"/><path d="M6.26 6.26A5.86 5.86 0 006 8c0 7-3 9-3 9h14"/><path d="M18 8a6 6 0 00-9.33-5"/><line x1="1" y1="1" x2="23" y2="23"/></svg>',
            trash: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3,6 5,6 21,6"/><path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"/></svg>',
            check: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20,6 9,17 4,12"/></svg>',
            user: '<svg viewBox="0 0 24 24" width="40" height="40" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>',
            chat: '<svg viewBox="0 0 24 24" width="60" height="60" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></svg>',
            key: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 11-7.778 7.778 5.5 5.5 0 017.777-7.777zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4"/></svg>',
            shield: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>',
            globe: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 014 10 15.3 15.3 0 01-4 10 15.3 15.3 0 01-4-10 15.3 15.3 0 014-10z"/></svg>',
            ai: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2L2 7l10 5 10-5-10-5z"/><path d="M2 17l10 5 10-5"/><path d="M2 12l10 5 10-5"/></svg>',
            download: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7,10 12,15 17,10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>',
            upload: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17,8 12,3 7,8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>',
            info: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>',
            phone: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07 19.5 19.5 0 01-6-6 19.79 19.79 0 01-3.07-8.67A2 2 0 014.11 2h3a2 2 0 012 1.72 12.84 12.84 0 00.7 2.81 2 2 0 01-.45 2.11L8.09 9.91a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45 12.84 12.84 0 002.81.7A2 2 0 0122 16.92z"/></svg>',
            lock: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0110 0v4"/></svg>',
            hash: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2"><line x1="4" y1="9" x2="20" y2="9"/><line x1="4" y1="15" x2="20" y2="15"/><line x1="10" y1="3" x2="8" y2="21"/><line x1="16" y1="3" x2="14" y2="21"/></svg>',
            arrowRight: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9,18 15,12 9,6"/></svg>',
            database: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2"><ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3"/><path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5"/></svg>',
            zap: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2"><polygon points="13,2 3,14 12,14 11,22 21,10 12,10"/></svg>'
        };
        return icons[name] || '';
    }

    var Toast = {
        _timeout: null,

        show: function(message, type, duration) {
            var toastEl = document.getElementById('zg-toast');
            if (!toastEl) return;

            if (this._timeout) {
                clearTimeout(this._timeout);
            }

            toastEl.textContent = message;
            toastEl.className = 'zg-toast';
            if (type === 'error') {
                toastEl.classList.add('zg-toast-error');
            } else if (type === 'success') {
                toastEl.classList.add('zg-toast-success');
            }

            var self = this;
            this._timeout = setTimeout(function() {
                toastEl.classList.add('zg-hidden');
            }, duration || 3000);
        }
    };

    var Modal = {
        show: function(options) {
            var overlay = document.getElementById('zg-modal');
            var body = document.getElementById('zg-modal-body');
            if (!overlay || !body) return;

            body.innerHTML = '';

            if (options.title) {
                var title = _el('h3', 'zg-modal-title', { textContent: options.title });
                body.appendChild(title);
            }

            if (options.text) {
                var text = _el('p', 'zg-modal-text', { textContent: options.text });
                body.appendChild(text);
            }

            if (options.content) {
                body.appendChild(options.content);
            }

            if (options.actions) {
                var actionsDiv = _el('div', 'zg-modal-actions');
                for (var i = 0; i < options.actions.length; i++) {
                    var action = options.actions[i];
                    var btn = _el('button', 'zg-btn ' + (action.className || 'zg-btn-secondary'), {
                        textContent: action.text,
                        onclick: (function(act) {
                            return function() {
                                Modal.hide();
                                if (act.handler) act.handler();
                            };
                        })(action)
                    });
                    actionsDiv.appendChild(btn);
                }
                body.appendChild(actionsDiv);
            }

            overlay.classList.remove('zg-hidden');

            overlay.addEventListener('click', function handler(e) {
                if (e.target === overlay) {
                    Modal.hide();
                    overlay.removeEventListener('click', handler);
                }
            });
        },

        hide: function() {
            var overlay = document.getElementById('zg-modal');
            if (overlay) {
                overlay.classList.add('zg-hidden');
            }
        }
    };

    var ScreenRenderer = {

        renderAccounts: function(container) {
            container.innerHTML = '';
            var page = _el('div', 'zg-page');

            var accounts = ZgStorage.Accounts.getAll();

            if (accounts.length === 0) {
                var empty = this._renderEmpty(
                    _svg('user'),
                    'Нет аккаунтов',
                    'Добавьте свой первый Telegram аккаунт, чтобы начать использовать ZeroGram',
                    'Добавить аккаунт',
                    function() {
                        window.location.hash = '#add-account';
                    }
                );
                page.appendChild(empty);
            } else {
                var header = _el('div', '', {
                    innerHTML: '<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px"><span class="zg-page-title" style="margin:0">Аккаунты (' + accounts.length + ')</span></div>'
                });
                page.appendChild(header);

                for (var i = 0; i < accounts.length; i++) {
                    var card = this._renderAccountCard(accounts[i]);
                    page.appendChild(card);
                }
            }

            var fab = _el('button', 'zg-fab', {
                innerHTML: _svg('plus'),
                onclick: function() {
                    window.location.hash = '#add-account';
                }
            });

            container.appendChild(page);
            container.appendChild(fab);
        },

        _renderAccountCard: function(account) {
            var activeId = ZgStorage.Accounts.getActiveId();
            var isActive = account.id === activeId;
            var isConnected = ZgTelegram.Connection.isConnected(account.id);

            var card = _el('div', 'zg-acc-card' + (isActive ? ' zg-selected' : '') + ' zg-ripple');

            var displayName = account.firstName || account.username || account.phone || 'Аккаунт';
            var letter = displayName.charAt(0).toUpperCase();

            var avatarColors = [
                ['#7c3aed', '#a78bfa'],
                ['#059669', '#34d399'],
                ['#d97706', '#fbbf24'],
                ['#dc2626', '#f87171'],
                ['#2563eb', '#60a5fa'],
                ['#7c3aed', '#c084fc'],
                ['#0891b2', '#22d3ee']
            ];
            var colorIndex = account.id.length % avatarColors.length;
            var gradColors = avatarColors[colorIndex];

            card.innerHTML = '' +
                '<div class="zg-acc-avatar" style="background:linear-gradient(135deg,' + gradColors[0] + ',' + gradColors[1] + ')">' +
                    letter +
                '</div>' +
                '<div class="zg-acc-details">' +
                    '<div class="zg-acc-name">' + this._escapeHtml(displayName) + '</div>' +
                    '<div class="zg-acc-phone">' + (account.phone ? '+' + account.phone : 'Номер не указан') + '</div>' +
                    '<div class="zg-acc-status">' +
                        '<span class="zg-acc-status-dot' + (isConnected ? '' : ' zg-offline') + '"></span>' +
                        '<span>' + (isConnected ? 'Подключён' : 'Не подключён') + '</span>' +
                        (!account.notificationsEnabled ? ' <span class="zg-muted-icon" title="Уведомления отключены">' + _svg('bellOff') + '</span>' : '') +
                    '</div>' +
                '</div>' +
                '<div class="zg-acc-actions">' +
                    '<button class="zg-btn-icon zg-acc-settings-btn" data-id="' + account.id + '" title="Настройки">' +
                        _svg('arrowRight') +
                    '</button>' +
                '</div>';

            card.addEventListener('click', function(e) {
                if (e.target.closest('.zg-acc-settings-btn')) {
                    e.stopPropagation();
                    window.location.hash = '#acc-settings/' + account.id;
                    return;
                }
                ZgStorage.Accounts.setActiveId(account.id);
                window.location.hash = '#chats';
            });

            return card;
        },

        renderAddAccount: function(container) {
            container.innerHTML = '';
            var flow = _el('div', 'zg-add-flow');

            var progress = _el('div', 'zg-progress-steps');
            for (var s = 0; s < 4; s++) {
                var step = _el('div', 'zg-progress-step' + (s === 0 ? ' zg-current' : ''));
                step.setAttribute('data-step', s);
                progress.appendChild(step);
            }
            flow.appendChild(progress);

            var step1 = this._renderAddStep1();
            var step2 = this._renderAddStep2();
            var step3 = this._renderAddStep3();
            var step4 = this._renderAddStep4();

            flow.appendChild(step1);
            flow.appendChild(step2);
            flow.appendChild(step3);
            flow.appendChild(step4);

            container.appendChild(flow);
        },

        _renderAddStep1: function() {
            var step = _el('div', 'zg-add-step zg-active', { 'data-step': '0' });
            step.innerHTML = '' +
                '<div class="zg-add-step-num">Шаг 1 из 4</div>' +
                '<div class="zg-add-step-title">API данные</div>' +
                '<div class="zg-add-step-desc">Введите API ID и API Hash из my.telegram.org. Это необходимо для подключения к Telegram.</div>' +
                '<div class="zg-input-group">' +
                    '<label class="zg-input-label">API ID</label>' +
                    '<input type="number" class="zg-input" id="zg-add-apiid" placeholder="Например: 12345678" autocomplete="off">' +
                    '<div class="zg-input-hint">Числовой идентификатор из my.telegram.org</div>' +
                '</div>' +
                '<div class="zg-input-group">' +
                    '<label class="zg-input-label">API Hash</label>' +
                    '<input type="text" class="zg-input" id="zg-add-apihash" placeholder="Например: 0123456789abcdef..." autocomplete="off">' +
                    '<div class="zg-input-hint">32-символьная строка из my.telegram.org</div>' +
                '</div>' +
                '<div id="zg-add-error1" class="zg-input-error zg-hidden"></div>' +
                '<button class="zg-btn zg-btn-primary zg-btn-full" id="zg-add-next1">Далее</button>';

            setTimeout(function() {
                var btn = document.getElementById('zg-add-next1');
                if (btn) {
                    btn.addEventListener('click', function() {
                        var apiId = document.getElementById('zg-add-apiid').value.trim();
                        var apiHash = document.getElementById('zg-add-apihash').value.trim();
                        var errorEl = document.getElementById('zg-add-error1');

                        if (!apiId || apiId.length === 0) {
                            errorEl.textContent = 'Введите API ID';
                            errorEl.classList.remove('zg-hidden');
                            return;
                        }

                        if (!apiHash || apiHash.length < 20) {
                            errorEl.textContent = 'Введите корректный API Hash';
                            errorEl.classList.remove('zg-hidden');
                            return;
                        }

                        errorEl.classList.add('zg-hidden');

                        var newAcc = ZgStorage.Accounts.add({
                            apiId: apiId,
                            apiHash: apiHash
                        });

                        window._zgAddAccountId = newAcc.id;
                        window._zgAddApiId = apiId;
                        window._zgAddApiHash = apiHash;

                        ScreenRenderer._goToStep(1);

                        ZgTelegram.Auth.startAuth(newAcc.id, apiId, apiHash, {
                            onConnected: function() {
                                console.log('[ZgUI] Подключён к Telegram');
                            },
                            onError: function(err) {
                                Toast.show(err, 'error');
                            }
                        });
                    });
                }
            }, 100);

            return step;
        },

        _renderAddStep2: function() {
            var step = _el('div', 'zg-add-step', { 'data-step': '1' });
            step.innerHTML = '' +
                '<div class="zg-add-step-num">Шаг 2 из 4</div>' +
                '<div class="zg-add-step-title">Номер телефона</div>' +
                '<div class="zg-add-step-desc">Введите номер телефона привязанный к Telegram аккаунту. Код страны обязателен.</div>' +
                '<div class="zg-input-group">' +
                    '<label class="zg-input-label">Номер телефона</label>' +
                    '<input type="tel" class="zg-input" id="zg-add-phone" placeholder="+375XXXXXXXXX" autocomplete="off">' +
                    '<div class="zg-input-hint">С кодом страны, например +375</div>' +
                '</div>' +
                '<div id="zg-add-error2" class="zg-input-error zg-hidden"></div>' +
                '<div id="zg-add-loading2" class="zg-hidden" style="text-align:center;padding:12px">' +
                    '<div class="zg-spinner"></div>' +
                    '<div style="margin-top:8px;font-size:13px;color:var(--zg-text-secondary)">Отправка кода...</div>' +
                '</div>' +
                '<button class="zg-btn zg-btn-primary zg-btn-full" id="zg-add-next2">Отправить код</button>';

            setTimeout(function() {
                var btn = document.getElementById('zg-add-next2');
                if (btn) {
                    btn.addEventListener('click', function() {
                        var phone = document.getElementById('zg-add-phone').value.trim();
                        var errorEl = document.getElementById('zg-add-error2');
                        var loadingEl = document.getElementById('zg-add-loading2');

                        if (!phone || phone.length < 8) {
                            errorEl.textContent = 'Введите корректный номер телефона';
                            errorEl.classList.remove('zg-hidden');
                            return;
                        }

                        if (phone.charAt(0) !== '+') {
                            phone = '+' + phone;
                        }

                        errorEl.classList.add('zg-hidden');
                        loadingEl.classList.remove('zg-hidden');
                        btn.disabled = true;

                        ZgTelegram.Auth.sendCode(phone, function(result) {
                            loadingEl.classList.add('zg-hidden');
                            btn.disabled = false;

                            if (result.success) {
                                Toast.show('Код отправлен', 'success');
                                ScreenRenderer._goToStep(2);
                            } else {
                                errorEl.textContent = result.error || 'Ошибка отправки кода';
                                errorEl.classList.remove('zg-hidden');
                            }
                        });
                    });
                }
            }, 100);

            return step;
        },

        _renderAddStep3: function() {
            var step = _el('div', 'zg-add-step', { 'data-step': '2' });
            step.innerHTML = '' +
                '<div class="zg-add-step-num">Шаг 3 из 4</div>' +
                '<div class="zg-add-step-title">Код подтверждения</div>' +
                '<div class="zg-add-step-desc">Введите код из SMS или из Telegram на другом устройстве.</div>' +
                '<div class="zg-input-group">' +
                    '<label class="zg-input-label">Код</label>' +
                    '<input type="text" class="zg-input" id="zg-add-code" placeholder="12345" autocomplete="one-time-code" inputmode="numeric" maxlength="6" style="text-align:center;font-size:24px;letter-spacing:8px;font-weight:700">' +
                '</div>' +
                '<div id="zg-add-error3" class="zg-input-error zg-hidden"></div>' +
                '<div id="zg-add-loading3" class="zg-hidden" style="text-align:center;padding:12px">' +
                    '<div class="zg-spinner"></div>' +
                    '<div style="margin-top:8px;font-size:13px;color:var(--zg-text-secondary)">Проверка кода...</div>' +
                '</div>' +
                '<button class="zg-btn zg-btn-primary zg-btn-full" id="zg-add-next3">Подтвердить</button>';

            setTimeout(function() {
                var btn = document.getElementById('zg-add-next3');
                if (btn) {
                    btn.addEventListener('click', function() {
                        var code = document.getElementById('zg-add-code').value.trim();
                        var errorEl = document.getElementById('zg-add-error3');
                        var loadingEl = document.getElementById('zg-add-loading3');

                        if (!code || code.length < 4) {
                            errorEl.textContent = 'Введите код из 5 цифр';
                            errorEl.classList.remove('zg-hidden');
                            return;
                        }

                        errorEl.classList.add('zg-hidden');
                        loadingEl.classList.remove('zg-hidden');
                        btn.disabled = true;

                        ZgTelegram.Auth.signIn(code, function(result) {
                            loadingEl.classList.add('zg-hidden');
                            btn.disabled = false;

                            if (result.success) {
                                Toast.show('Аккаунт добавлен!', 'success');
                                ZgStorage.Accounts.setActiveId(window._zgAddAccountId);
                                window.location.hash = '#accounts';
                            } else if (result.needsPassword) {
                                ScreenRenderer._goToStep(3);
                            } else {
                                errorEl.textContent = result.error || 'Неверный код';
                                errorEl.classList.remove('zg-hidden');
                                document.getElementById('zg-add-code').classList.add('zg-shake');
                                setTimeout(function() {
                                    document.getElementById('zg-add-code').classList.remove('zg-shake');
                                }, 600);
                            }
                        });
                    });
                }
            }, 100);

            return step;
        },

        _renderAddStep4: function() {
            var step = _el('div', 'zg-add-step', { 'data-step': '3' });
            step.innerHTML = '' +
                '<div class="zg-add-step-num">Шаг 4 из 4</div>' +
                '<div class="zg-add-step-title">Двухфакторная аутентификация</div>' +
                '<div class="zg-add-step-desc">У вас включена двухфакторная аутентификация. Введите облачный пароль.</div>' +
                '<div class="zg-input-group">' +
                    '<label class="zg-input-label">Пароль 2FA</label>' +
                    '<input type="password" class="zg-input" id="zg-add-password" placeholder="Ваш облачный пароль" autocomplete="current-password">' +
                '</div>' +
                '<div id="zg-add-error4" class="zg-input-error zg-hidden"></div>' +
                '<div id="zg-add-loading4" class="zg-hidden" style="text-align:center;padding:12px">' +
                    '<div class="zg-spinner"></div>' +
                    '<div style="margin-top:8px;font-size:13px;color:var(--zg-text-secondary)">Проверка пароля...</div>' +
                '</div>' +
                '<button class="zg-btn zg-btn-primary zg-btn-full" id="zg-add-next4">Войти</button>';

            setTimeout(function() {
                var btn = document.getElementById('zg-add-next4');
                if (btn) {
                    btn.addEventListener('click', function() {
                        var password = document.getElementById('zg-add-password').value;
                        var errorEl = document.getElementById('zg-add-error4');
                        var loadingEl = document.getElementById('zg-add-loading4');

                        if (!password || password.length === 0) {
                            errorEl.textContent = 'Введите пароль';
                            errorEl.classList.remove('zg-hidden');
                            return;
                        }

                        errorEl.classList.add('zg-hidden');
                        loadingEl.classList.remove('zg-hidden');
                        btn.disabled = true;

                        ZgTelegram.Auth.signInWithPassword(password, function(result) {
                            loadingEl.classList.add('zg-hidden');
                            btn.disabled = false;

                            if (result.success) {
                                Toast.show('Аккаунт добавлен!', 'success');
                                ZgStorage.Accounts.setActiveId(window._zgAddAccountId);
                                window.location.hash = '#accounts';
                            } else {
                                errorEl.textContent = result.error || 'Неверный пароль';
                                errorEl.classList.remove('zg-hidden');
                            }
                        });
                    });
                }
            }, 100);

            return step;
        },

        _goToStep: function(stepIndex) {
            var steps = document.querySelectorAll('.zg-add-step');
            var progressSteps = document.querySelectorAll('.zg-progress-step');

            for (var i = 0; i < steps.length; i++) {
                steps[i].classList.remove('zg-active');
            }
            for (var j = 0; j < progressSteps.length; j++) {
                progressSteps[j].classList.remove('zg-done', 'zg-current');
                if (j < stepIndex) {
                    progressSteps[j].classList.add('zg-done');
                } else if (j === stepIndex) {
                    progressSteps[j].classList.add('zg-current');
                }
            }

            steps[stepIndex].classList.add('zg-active');
        },

        renderChats: function(container) {
            container.innerHTML = '';
            var page = _el('div', '');

            var accounts = ZgStorage.Accounts.getAll();
            var activeAccount = ZgStorage.Accounts.getActive();

            if (accounts.length === 0) {
                var empty = this._renderEmpty(
                    _svg('chat'),
                    'Нет аккаунтов',
                    'Сначала добавьте Telegram аккаунт',
                    'Добавить аккаунт',
                    function() {
                        window.location.hash = '#add-account';
                    }
                );
                page.appendChild(empty);
                container.appendChild(page);
                return;
            }

            if (accounts.length > 1) {
                var switcher = _el('div', 'zg-acc-switch');
                for (var a = 0; a < accounts.length; a++) {
                    var acc = accounts[a];
                    var chipName = acc.firstName || acc.username || acc.phone || 'Акк';
                    var isActive = activeAccount && acc.id === activeAccount.id;
                    var chip = _el('button', 'zg-acc-chip' + (isActive ? ' zg-active' : ''));
                    chip.innerHTML = '<span class="zg-acc-chip-dot" style="background:' + (ZgTelegram.Connection.isConnected(acc.id) ? 'var(--zg-success)' : 'var(--zg-text-muted)') + '"></span>' + this._escapeHtml(chipName);
                    chip.setAttribute('data-id', acc.id);
                    chip.addEventListener('click', function() {
                        var accId = this.getAttribute('data-id');
                        ZgStorage.Accounts.setActiveId(accId);
                        ScreenRenderer.renderChats(container);
                    });
                    switcher.appendChild(chip);
                }
                page.appendChild(switcher);
            }

            var searchWrap = _el('div', 'zg-search-wrap');
            searchWrap.innerHTML = '<span class="zg-search-icon">' + _svg('search') + '</span><input type="text" class="zg-search" id="zg-chat-search" placeholder="Поиск чатов...">';
            page.appendChild(searchWrap);

            var chatList = _el('div', 'zg-page', { id: 'zg-chat-list' });

            if (!activeAccount || !ZgTelegram.Connection.isConnected(activeAccount.id)) {
                var connectMsg = _el('div', 'zg-empty');
                connectMsg.innerHTML = '' +
                    '<div class="zg-empty-icon">' + _svg('globe') + '</div>' +
                    '<div class="zg-empty-title">Не подключён</div>' +
                    '<div class="zg-empty-desc">Аккаунт не подключён к Telegram. Попробуйте переподключиться.</div>' +
                    '<button class="zg-btn zg-btn-primary" id="zg-reconnect-btn">Подключиться</button>';
                chatList.appendChild(connectMsg);

                setTimeout(function() {
                    var reconnBtn = document.getElementById('zg-reconnect-btn');
                    if (reconnBtn && activeAccount) {
                        reconnBtn.addEventListener('click', function() {
                            reconnBtn.disabled = true;
                            reconnBtn.innerHTML = '<div class="zg-spinner"></div> Подключение...';
                            ZgTelegram.Session.restoreSession(activeAccount.id, function(result) {
                                if (result.success) {
                                    Toast.show('Подключено!', 'success');
                                    ScreenRenderer.renderChats(container);
                                } else {
                                    Toast.show(result.error || 'Ошибка подключения', 'error');
                                    reconnBtn.disabled = false;
                                    reconnBtn.textContent = 'Подключиться';
                                }
                            });
                        });
                    }
                }, 100);
            } else {
                var loadingDiv = _el('div', '', {
                    innerHTML: '<div style="text-align:center;padding:40px"><div class="zg-spinner zg-spinner-lg"></div><div style="margin-top:12px;color:var(--zg-text-secondary);font-size:13px">Загрузка чатов...</div></div>'
                });
                chatList.appendChild(loadingDiv);

                ZgTelegram.Chat.getDialogs(activeAccount.id, { limit: 40 }, function(result) {
                    chatList.innerHTML = '';

                    if (!result.success || !result.dialogs || result.dialogs.length === 0) {
                        var emptyChats = _el('div', 'zg-empty');
                        emptyChats.innerHTML = '<div class="zg-empty-icon">' + _svg('chat') + '</div><div class="zg-empty-title">Нет чатов</div><div class="zg-empty-desc">У этого аккаунта пока нет чатов</div>';
                        chatList.appendChild(emptyChats);
                        return;
                    }

                    for (var d = 0; d < result.dialogs.length; d++) {
                        var card = ScreenRenderer._renderChatCard(result.dialogs[d]);
                        chatList.appendChild(card);
                    }
                });
            }

            page.appendChild(chatList);
            container.appendChild(page);

            setTimeout(function() {
                var searchInput = document.getElementById('zg-chat-search');
                if (searchInput) {
                    searchInput.addEventListener('input', function() {
                        var query = this.value.toLowerCase();
                        var cards = chatList.querySelectorAll('.zg-card');
                        for (var c = 0; c < cards.length; c++) {
                            var name = cards[c].querySelector('.zg-card-name');
                            if (name) {
                                var text = name.textContent.toLowerCase();
                                cards[c].style.display = text.indexOf(query) !== -1 ? '' : 'none';
                            }
                        }
                    });
                }
            }, 200);
        },

        _renderChatCard: function(dialog) {
            var card = _el('div', 'zg-card zg-ripple');

            var typeIcons = {
                'channel': '#0891b2',
                'supergroup': '#059669',
                'chat': '#059669',
                'user': '#7c3aed',
                'bot': '#d97706'
            };
            var avatarColor = typeIcons[dialog.type] || '#7c3aed';

            var lastMsgText = '';
            var lastMsgTime = '';
            if (dialog.lastMessage) {
                lastMsgText = dialog.lastMessage.text || (dialog.lastMessage.media ? '[Медиа]' : '');
                if (lastMsgText.length > 50) {
                    lastMsgText = lastMsgText.substring(0, 50) + '...';
                }
                if (dialog.lastMessage.out) {
                    lastMsgText = 'Вы: ' + lastMsgText;
                }
                lastMsgTime = this._formatTime(dialog.lastMessage.date);
            }

            var typeLabel = '';
            if (dialog.type === 'channel') typeLabel = 'Канал';
            else if (dialog.type === 'supergroup') typeLabel = 'Группа';
            else if (dialog.type === 'chat') typeLabel = 'Группа';
            else if (dialog.bot) typeLabel = 'Бот';

            card.innerHTML = '' +
                '<div class="zg-card-row">' +
                    '<div class="zg-card-avatar" style="background:linear-gradient(135deg,' + avatarColor + ',' + this._lightenColor(avatarColor) + ')">' +
                        (dialog.letter || '?') +
                        (dialog.online ? '<span class="zg-online-dot"></span>' : '') +
                    '</div>' +
                    '<div class="zg-card-body">' +
                        '<div class="zg-card-name">' +
                            this._escapeHtml(dialog.title || 'Неизвестный') +
                            (typeLabel ? ' <span style="font-size:11px;color:var(--zg-text-muted);font-weight:400">' + typeLabel + '</span>' : '') +
                        '</div>' +
                        '<div class="zg-card-info">' + this._escapeHtml(lastMsgText) + '</div>' +
                    '</div>' +
                    '<div class="zg-card-meta">' +
                        '<span class="zg-card-time">' + lastMsgTime + '</span>' +
                        (dialog.unreadCount > 0 ? '<span class="zg-card-badge">' + (dialog.unreadCount > 99 ? '99+' : dialog.unreadCount) + '</span>' : '') +
                        (dialog.pinned ? '<span style="font-size:11px;color:var(--zg-text-muted)">&#128204;</span>' : '') +
                    '</div>' +
                '</div>';

            card.addEventListener('click', function() {
                window.location.hash = '#chat/' + dialog.id + '/' + (dialog.type || 'user');
            });

            return card;
        },

        renderChat: function(container, chatId, chatType) {
            container.innerHTML = '';
            var chatContainer = _el('div', 'zg-chat-container');

            var messagesDiv = _el('div', 'zg-chat-messages', { id: 'zg-messages' });
            messagesDiv.innerHTML = '<div style="text-align:center;padding:40px"><div class="zg-spinner zg-spinner-lg"></div></div>';
            chatContainer.appendChild(messagesDiv);

            var groqConfig = ZgStorage.Settings.getGroqConfig();
            var inputArea = _el('div', 'zg-chat-input-area');
            var inputWrap = _el('div', 'zg-chat-input-wrap');

            if (groqConfig.enabled && groqConfig.apiKey) {
                var groqBadge = _el('span', 'zg-chat-groq-badge', { textContent: 'GROQ AI' });
                inputWrap.appendChild(groqBadge);
            }

            inputWrap.innerHTML += '<textarea class="zg-chat-input" id="zg-msg-input" placeholder="Сообщение..." rows="1"></textarea>';
            inputArea.appendChild(inputWrap);

            var sendBtn = _el('button', 'zg-chat-send-btn', {
                innerHTML: _svg('send'),
                id: 'zg-send-btn'
            });
            inputArea.appendChild(sendBtn);
            chatContainer.appendChild(inputArea);

            container.appendChild(chatContainer);

            var activeAccount = ZgStorage.Accounts.getActive();
            if (activeAccount && ZgTelegram.Connection.isConnected(activeAccount.id)) {
                ZgTelegram.Chat.getMessages(activeAccount.id, chatId, { limit: 50 }, function(result) {
                    messagesDiv.innerHTML = '';
                    if (result.success && result.messages) {
                        for (var m = 0; m < result.messages.length; m++) {
                            var msgEl = ScreenRenderer._renderMessage(result.messages[m]);
                            messagesDiv.appendChild(msgEl);
                        }
                        messagesDiv.scrollTop = messagesDiv.scrollHeight;
                    } else {
                        messagesDiv.innerHTML = '<div style="text-align:center;padding:20px;color:var(--zg-text-muted)">Не удалось загрузить сообщения</div>';
                    }
                });
            }

            setTimeout(function() {
                var msgInput = document.getElementById('zg-msg-input');
                var sendBtnEl = document.getElementById('zg-send-btn');

                if (msgInput) {
                    msgInput.addEventListener('input', function() {
                        this.style.height = 'auto';
                        this.style.height = Math.min(this.scrollHeight, 120) + 'px';
                    });

                    msgInput.addEventListener('keydown', function(e) {
                        if (e.key === 'Enter' && !e.shiftKey) {
                            e.preventDefault();
                            ScreenRenderer._sendMessage(chatId, chatType);
                        }
                    });
                }

                if (sendBtnEl) {
                    sendBtnEl.addEventListener('click', function() {
                        ScreenRenderer._sendMessage(chatId, chatType);
                    });
                }
            }, 100);
        },

        _sendMessage: function(chatId, chatType) {
            var input = document.getElementById('zg-msg-input');
            if (!input) return;

            var text = input.value.trim();
            if (text.length === 0) return;

            var activeAccount = ZgStorage.Accounts.getActive();
            if (!activeAccount) return;

            var groqConfig = ZgStorage.Settings.getGroqConfig();

            var sendFn = function(finalText) {
                var messagesDiv = document.getElementById('zg-messages');
                if (messagesDiv) {
                    var tempMsg = _el('div', 'zg-msg zg-msg-out');
                    tempMsg.innerHTML = '<div class="zg-msg-text">' + ScreenRenderer._escapeHtml(finalText) + '</div><div class="zg-msg-time">Отправка...</div>';
                    messagesDiv.appendChild(tempMsg);
                    messagesDiv.scrollTop = messagesDiv.scrollHeight;
                }

                input.value = '';
                input.style.height = 'auto';

                ZgTelegram.Chat.sendMessage(activeAccount.id, chatId, finalText, function(result) {
                    if (result.success) {
                        if (tempMsg) {
                            var timeEl = tempMsg.querySelector('.zg-msg-time');
                            if (timeEl) {
                                timeEl.textContent = ScreenRenderer._formatTime(Math.floor(Date.now() / 1000));
                            }
                        }
                    } else {
                        Toast.show('Ошибка отправки: ' + (result.error || ''), 'error');
                        if (tempMsg) {
                            tempMsg.style.opacity = '0.5';
                            var timeEl = tempMsg.querySelector('.zg-msg-time');
                            if (timeEl) {
                                timeEl.textContent = 'Ошибка';
                                timeEl.style.color = 'var(--zg-error)';
                            }
                        }
                    }
                });
            };

            if (groqConfig.enabled && groqConfig.apiKey && text.length >= 10) {
                Toast.show('Groq AI обрабатывает текст...', 'info');
                var sendBtn = document.getElementById('zg-send-btn');
                if (sendBtn) sendBtn.disabled = true;

                ZgGroq.restructureText(text, function(result) {
                    if (sendBtn) sendBtn.disabled = false;

                    if (result.success) {
                        sendFn(result.text);
                    } else {
                        Toast.show('Groq ошибка: ' + result.error + '. Отправка без обработки.', 'error');
                        sendFn(text);
                    }
                });
            } else {
                sendFn(text);
            }
        },

        _renderMessage: function(msg) {
            var msgEl = _el('div', 'zg-msg ' + (msg.out ? 'zg-msg-out' : 'zg-msg-in'));
            var html = '';

            if (!msg.out && msg.fromId) {
                html += '<div class="zg-msg-sender">ID: ' + msg.fromId + '</div>';
            }

            html += '<div class="zg-msg-text">' + this._escapeHtml(msg.text || (msg.media ? '[Медиа]' : '')) + '</div>';
            html += '<div class="zg-msg-time">' + this._formatTime(msg.date) + (msg.edited ? ' (ред.)' : '') + '</div>';

            msgEl.innerHTML = html;
            return msgEl;
        },

        renderSettings: function(container) {
            container.innerHTML = '';
            var page = _el('div', 'zg-page');

            page.innerHTML += '<div class="zg-page-title">Настройки</div>';

            var groqSection = _el('div', 'zg-settings-section');
            groqSection.innerHTML = '' +
                '<div class="zg-settings-section-title">Groq AI</div>' +
                '<div class="zg-settings-card">' +
                    '<div class="zg-toggle-row">' +
                        '<div class="zg-toggle-info">' +
                            '<div class="zg-toggle-title">Структурирование текста</div>' +
                            '<div class="zg-toggle-desc">AI улучшает структуру текста перед отправкой</div>' +
                        '</div>' +
                        '<label class="zg-toggle">' +
                            '<input type="checkbox" id="zg-groq-toggle" ' + (ZgGroq.isEnabled() ? 'checked' : '') + '>' +
                            '<span class="zg-toggle-slider"></span>' +
                        '</label>' +
                    '</div>' +
                '</div>' +
                '<div style="margin-top:12px" class="zg-settings-card">' +
                    '<div style="padding:12px 0">' +
                        '<div class="zg-input-group" style="margin-bottom:12px">' +
                            '<label class="zg-input-label">API ключ Groq</label>' +
                            '<input type="password" class="zg-input" id="zg-groq-key" value="' + (ZgGroq.getApiKey() || '') + '" placeholder="gsk_...">' +
                            '<div class="zg-input-hint">Бесплатно на console.groq.com</div>' +
                        '</div>' +
                        '<div class="zg-input-group" style="margin-bottom:12px">' +
                            '<label class="zg-input-label">Модель</label>' +
                            '<select class="zg-input" id="zg-groq-model" style="height:48px">' +
                            '</select>' +
                        '</div>' +
                        '<div style="display:flex;gap:8px">' +
                            '<button class="zg-btn zg-btn-secondary zg-btn-sm" id="zg-groq-test">Тест соединения</button>' +
                            '<button class="zg-btn zg-btn-primary zg-btn-sm" id="zg-groq-save">Сохранить</button>' +
                        '</div>' +
                    '</div>' +
                '</div>';
            page.appendChild(groqSection);

            var notifSection = _el('div', 'zg-settings-section');
            notifSection.innerHTML = '' +
                '<div class="zg-settings-section-title">Уведомления</div>' +
                '<div class="zg-settings-card">' +
                    '<div class="zg-toggle-row">' +
                        '<div class="zg-toggle-info">' +
                            '<div class="zg-toggle-title">Глобальные уведомления</div>' +
                            '<div class="zg-toggle-desc">Все уведомления от всех аккаунтов</div>' +
                        '</div>' +
                        '<label class="zg-toggle">' +
                            '<input type="checkbox" id="zg-notif-global" ' + (ZgStorage.Settings.get('notificationsGlobal') !== false ? 'checked' : '') + '>' +
                            '<span class="zg-toggle-slider"></span>' +
                        '</label>' +
                    '</div>' +
                '</div>';
            page.appendChild(notifSection);

            var dataSection = _el('div', 'zg-settings-section');
            var storageInfo = ZgStorage.getStorageUsage();
            dataSection.innerHTML = '' +
                '<div class="zg-settings-section-title">Данные</div>' +
                '<div class="zg-settings-card">' +
                    '<div class="zg-settings-item" id="zg-export-data">' +
                        '<div class="zg-settings-icon zg-green">' + _svg('download') + '</div>' +
                        '<div class="zg-settings-text">' +
                            '<div class="zg-settings-text-title">Экспорт данных</div>' +
                            '<div class="zg-settings-text-desc">Сохранить аккаунты и настройки</div>' +
                        '</div>' +
                        '<span class="zg-settings-arrow">' + _svg('arrowRight') + '</span>' +
                    '</div>' +
                    '<div class="zg-settings-item" id="zg-import-data">' +
                        '<div class="zg-settings-icon zg-purple">' + _svg('upload') + '</div>' +
                        '<div class="zg-settings-text">' +
                            '<div class="zg-settings-text-title">Импорт данных</div>' +
                            '<div class="zg-settings-text-desc">Восстановить из файла</div>' +
                        '</div>' +
                        '<span class="zg-settings-arrow">' + _svg('arrowRight') + '</span>' +
                    '</div>' +
                    '<div class="zg-settings-item" id="zg-clear-cache">' +
                        '<div class="zg-settings-icon zg-yellow">' + _svg('database') + '</div>' +
                        '<div class="zg-settings-text">' +
                            '<div class="zg-settings-text-title">Очистить кэш</div>' +
                            '<div class="zg-settings-text-desc">Используется: ' + storageInfo.formatted + '</div>' +
                        '</div>' +
                        '<span class="zg-settings-arrow">' + _svg('arrowRight') + '</span>' +
                    '</div>' +
                    '<div class="zg-settings-item" id="zg-clear-all">' +
                        '<div class="zg-settings-icon zg-red">' + _svg('trash') + '</div>' +
                        '<div class="zg-settings-text">' +
                            '<div class="zg-settings-text-title">Удалить все данные</div>' +
                            '<div class="zg-settings-text-desc">Сбросить приложение полностью</div>' +
                        '</div>' +
                        '<span class="zg-settings-arrow">' + _svg('arrowRight') + '</span>' +
                    '</div>' +
                '</div>';
            page.appendChild(dataSection);

            var aboutSection = _el('div', 'zg-settings-section');
            aboutSection.innerHTML = '' +
                '<div class="zg-settings-section-title">О приложении</div>' +
                '<div class="zg-settings-card">' +
                    '<div style="padding:16px 0;text-align:center">' +
                        '<div style="font-size:18px;font-weight:700;margin-bottom:4px">ZeroGram</div>' +
                        '<div style="font-size:13px;color:var(--zg-text-secondary)">v1.0.0</div>' +
                        '<div style="font-size:12px;color:var(--zg-text-muted);margin-top:8px">by Re:Zero</div>' +
                        '<div style="font-size:11px;color:var(--zg-text-muted);margin-top:4px">Telegram без границ</div>' +
                    '</div>' +
                '</div>';
            page.appendChild(aboutSection);

            container.appendChild(page);

            setTimeout(function() {
                var modelSelect = document.getElementById('zg-groq-model');
                if (modelSelect) {
                    var models = ZgGroq.getAvailableModels();
                    var currentModel = ZgGroq.getModel();
                    for (var m = 0; m < models.length; m++) {
                        var opt = _el('option', '', { value: models[m].id, textContent: models[m].name + ' — ' + models[m].description });
                        if (models[m].id === currentModel) {
                            opt.selected = true;
                        }
                        modelSelect.appendChild(opt);
                    }
                }

                var groqToggle = document.getElementById('zg-groq-toggle');
                if (groqToggle) {
                    groqToggle.addEventListener('change', function() {
                        ZgGroq.setEnabled(this.checked);
                    });
                }

                var groqSave = document.getElementById('zg-groq-save');
                if (groqSave) {
                    groqSave.addEventListener('click', function() {
                        var key = document.getElementById('zg-groq-key').value.trim();
                        var model = document.getElementById('zg-groq-model').value;
                        ZgGroq.setApiKey(key);
                        ZgGroq.setModel(model);
                        Toast.show('Настройки Groq сохранены', 'success');
                    });
                }

                var groqTest = document.getElementById('zg-groq-test');
                if (groqTest) {
                    groqTest.addEventListener('click', function() {
                        var key = document.getElementById('zg-groq-key').value.trim();
                        if (!key) {
                            Toast.show('Введите API ключ', 'error');
                            return;
                        }
                        ZgGroq.setApiKey(key);
                        groqTest.disabled = true;
                        groqTest.textContent = 'Проверка...';
                        ZgGroq.testConnection(function(result) {
                            groqTest.disabled = false;
                            groqTest.textContent = 'Тест соединения';
                            if (result.success) {
                                Toast.show('Groq подключён!', 'success');
                            } else {
                                Toast.show('Ошибка: ' + result.error, 'error');
                            }
                        });
                    });
                }

                var notifGlobal = document.getElementById('zg-notif-global');
                if (notifGlobal) {
                    notifGlobal.addEventListener('change', function() {
                        ZgStorage.Settings.set('notificationsGlobal', this.checked);
                        Toast.show(this.checked ? 'Уведомления включены' : 'Уведомления отключены');
                    });
                }

                var exportBtn = document.getElementById('zg-export-data');
                if (exportBtn) {
                    exportBtn.addEventListener('click', function() {
                        var data = ZgStorage.exportData();
                        var blob = new Blob([data], { type: 'application/json' });
                        var url = URL.createObjectURL(blob);
                        var a = document.createElement('a');
                        a.href = url;
                        a.download = 'zerogram_backup_' + new Date().toISOString().split('T')[0] + '.json';
                        a.click();
                        URL.revokeObjectURL(url);
                        Toast.show('Данные экспортированы', 'success');
                    });
                }

                var importBtn = document.getElementById('zg-import-data');
                if (importBtn) {
                    importBtn.addEventListener('click', function() {
                        var fileInput = document.createElement('input');
                        fileInput.type = 'file';
                        fileInput.accept = '.json';
                        fileInput.addEventListener('change', function(e) {
                            var file = e.target.files[0];
                            if (!file) return;
                            var reader = new FileReader();
                            reader.onload = function(ev) {
                                var result = ZgStorage.importData(ev.target.result);
                                if (result.success) {
                                    Toast.show('Данные импортированы! Перезагрузка...', 'success');
                                    setTimeout(function() { location.reload(); }, 1500);
                                } else {
                                    Toast.show('Ошибка импорта: ' + result.error, 'error');
                                }
                            };
                            reader.readAsText(file);
                        });
                        fileInput.click();
                    });
                }

                var clearCache = document.getElementById('zg-clear-cache');
                if (clearCache) {
                    clearCache.addEventListener('click', function() {
                        ZgStorage.Cache.clearAll();
                        Toast.show('Кэш очищен', 'success');
                    });
                }

                var clearAll = document.getElementById('zg-clear-all');
                if (clearAll) {
                    clearAll.addEventListener('click', function() {
                        Modal.show({
                            title: 'Удалить все данные?',
                            text: 'Это действие нельзя отменить. Все аккаунты, сессии и настройки будут удалены.',
                            actions: [
                                { text: 'Отмена', className: 'zg-btn-secondary' },
                                {
                                    text: 'Удалить',
                                    className: 'zg-btn-danger',
                                    handler: function() {
                                        ZgStorage.clearAllData();
                                        Toast.show('Данные удалены. Перезагрузка...', 'success');
                                        setTimeout(function() { location.reload(); }, 1500);
                                    }
                                }
                            ]
                        });
                    });
                }
            }, 100);
        },

        renderAccountSettings: function(container, accountId) {
            container.innerHTML = '';
            var page = _el('div', 'zg-page');

            var account = ZgStorage.Accounts.getById(accountId);
            if (!account) {
                page.innerHTML = '<div class="zg-empty"><div class="zg-empty-title">Аккаунт не найден</div></div>';
                container.appendChild(page);
                return;
            }

            var displayName = account.firstName || account.username || account.phone || 'Аккаунт';

            page.innerHTML = '' +
                '<div style="text-align:center;padding:20px 0 30px">' +
                    '<div class="zg-acc-avatar" style="width:80px;height:80px;font-size:32px;margin:0 auto 12px;background:linear-gradient(135deg,var(--zg-accent),var(--zg-accent-light))">' + displayName.charAt(0).toUpperCase() + '</div>' +
                    '<div style="font-size:20px;font-weight:700">' + this._escapeHtml(displayName) + '</div>' +
                    (account.username ? '<div style="font-size:14px;color:var(--zg-accent-light);margin-top:4px">@' + this._escapeHtml(account.username) + '</div>' : '') +
                    '<div style="font-size:13px;color:var(--zg-text-secondary);margin-top:4px">' + (account.phone ? '+' + account.phone : '') + '</div>' +
                '</div>';

            var notifSection = _el('div', 'zg-settings-section');
            notifSection.innerHTML = '' +
                '<div class="zg-settings-section-title">Уведомления</div>' +
                '<div class="zg-settings-card">' +
                    '<div class="zg-toggle-row">' +
                        '<div class="zg-toggle-info">' +
                            '<div class="zg-toggle-title">Уведомления от этого аккаунта</div>' +
                            '<div class="zg-toggle-desc">Если выключено, все уведомления от этого аккаунта будут игнорироваться</div>' +
                        '</div>' +
                        '<label class="zg-toggle">' +
                            '<input type="checkbox" id="zg-acc-notif" ' + (account.notificationsEnabled ? 'checked' : '') + '>' +
                            '<span class="zg-toggle-slider"></span>' +
                        '</label>' +
                    '</div>' +
                '</div>';
            page.appendChild(notifSection);

            var infoSection = _el('div', 'zg-settings-section');
            infoSection.innerHTML = '' +
                '<div class="zg-settings-section-title">Информация</div>' +
                '<div class="zg-settings-card">' +
                    '<div class="zg-settings-item" style="cursor:default">' +
                        '<div class="zg-settings-icon zg-purple">' + _svg('key') + '</div>' +
                        '<div class="zg-settings-text">' +
                            '<div class="zg-settings-text-title">API ID</div>' +
                            '<div class="zg-settings-text-desc">' + account.apiId + '</div>' +
                        '</div>' +
                    '</div>' +
                    '<div class="zg-settings-item" style="cursor:default">' +
                        '<div class="zg-settings-icon zg-purple">' + _svg('hash') + '</div>' +
                        '<div class="zg-settings-text">' +
                            '<div class="zg-settings-text-title">API Hash</div>' +
                            '<div class="zg-settings-text-desc">' + account.apiHash.substring(0, 8) + '...' + '</div>' +
                        '</div>' +
                    '</div>' +
                    '<div class="zg-settings-item" style="cursor:default">' +
                        '<div class="zg-settings-icon zg-green">' + _svg('shield') + '</div>' +
                        '<div class="zg-settings-text">' +
                            '<div class="zg-settings-text-title">Статус подключения</div>' +
                            '<div class="zg-settings-text-desc">' + (ZgTelegram.Connection.isConnected(accountId) ? 'Подключён' : 'Не подключён') + '</div>' +
                        '</div>' +
                    '</div>' +
                    '<div class="zg-settings-item" style="cursor:default">' +
                        '<div class="zg-settings-icon zg-yellow">' + _svg('zap') + '</div>' +
                        '<div class="zg-settings-text">' +
                            '<div class="zg-settings-text-title">Добавлен</div>' +
                            '<div class="zg-settings-text-desc">' + new Date(account.createdAt).toLocaleDateString('ru-RU') + '</div>' +
                        '</div>' +
                    '</div>' +
                '</div>';
            page.appendChild(infoSection);

            var dangerSection = _el('div', 'zg-settings-section');
            dangerSection.innerHTML = '' +
                '<div class="zg-settings-section-title">Опасная зона</div>' +
                '<div class="zg-settings-card">' +
                    '<div class="zg-settings-item" id="zg-acc-disconnect">' +
                        '<div class="zg-settings-icon zg-yellow">' + _svg('globe') + '</div>' +
                        '<div class="zg-settings-text">' +
                            '<div class="zg-settings-text-title">Отключить сессию</div>' +
                            '<div class="zg-settings-text-desc">Разорвать текущее соединение</div>' +
                        '</div>' +
                        '<span class="zg-settings-arrow">' + _svg('arrowRight') + '</span>' +
                    '</div>' +
                    '<div class="zg-settings-item" id="zg-acc-remove">' +
                        '<div class="zg-settings-icon zg-red">' + _svg('trash') + '</div>' +
                        '<div class="zg-settings-text">' +
                            '<div class="zg-settings-text-title">Удалить аккаунт</div>' +
                            '<div class="zg-settings-text-desc">Удалить из ZeroGram (не из Telegram)</div>' +
                        '</div>' +
                        '<span class="zg-settings-arrow">' + _svg('arrowRight') + '</span>' +
                    '</div>' +
                '</div>';
            page.appendChild(dangerSection);

            container.appendChild(page);

            setTimeout(function() {
                var notifToggle = document.getElementById('zg-acc-notif');
                if (notifToggle) {
                    notifToggle.addEventListener('change', function() {
                        ZgStorage.Accounts.setNotifications(accountId, this.checked);
                        Toast.show(this.checked ? 'Уведомления включены' : 'Уведомления отключены');
                    });
                }

                var disconnectBtn = document.getElementById('zg-acc-disconnect');
                if (disconnectBtn) {
                    disconnectBtn.addEventListener('click', function() {
                        ZgTelegram.Connection.disconnect(accountId);
                        Toast.show('Сессия отключена');
                        ScreenRenderer.renderAccountSettings(container, accountId);
                    });
                }

                var removeBtn = document.getElementById('zg-acc-remove');
                if (removeBtn) {
                    removeBtn.addEventListener('click', function() {
                        Modal.show({
                            title: 'Удалить аккаунт?',
                            text: 'Аккаунт "' + displayName + '" будет удалён из ZeroGram. Это не удалит ваш Telegram аккаунт.',
                            actions: [
                                { text: 'Отмена', className: 'zg-btn-secondary' },
                                {
                                    text: 'Удалить',
                                    className: 'zg-btn-danger',
                                    handler: function() {
                                        ZgTelegram.Connection.disconnect(accountId);
                                        ZgStorage.Accounts.remove(accountId);
                                        Toast.show('Аккаунт удалён', 'success');
                                        window.location.hash = '#accounts';
                                    }
                                }
                            ]
                        });
                    });
                }
            }, 100);
        },

        _renderEmpty: function(iconHtml, title, description, btnText, btnHandler) {
            var empty = _el('div', 'zg-empty');
            empty.innerHTML = '<div class="zg-empty-icon">' + iconHtml + '</div>' +
                '<div class="zg-empty-title">' + title + '</div>' +
                '<div class="zg-empty-desc">' + description + '</div>';

            if (btnText && btnHandler) {
                var btn = _el('button', 'zg-btn zg-btn-primary', {
                    textContent: btnText,
                    onclick: btnHandler
                });
                empty.appendChild(btn);
            }
            return empty;
        },

        _formatTime: function(timestamp) {
            if (!timestamp) return '';
            var date = new Date(timestamp * 1000);
            var now = new Date();
            var diffDays = Math.floor((now - date) / (1000 * 60 * 60 * 24));

            if (diffDays === 0) {
                return date.getHours().toString().padStart(2, '0') + ':' + date.getMinutes().toString().padStart(2, '0');
            } else if (diffDays === 1) {
                return 'Вчера';
            } else if (diffDays < 7) {
                var days = ['Вс', 'Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб'];
                return days[date.getDay()];
            } else {
                return date.getDate().toString().padStart(2, '0') + '.' + (date.getMonth() + 1).toString().padStart(2, '0');
            }
        },

        _escapeHtml: function(str) {
            if (!str) return '';
            return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
        },

        _lightenColor: function(hex) {
            var colorMap = {
                '#7c3aed': '#a78bfa',
                '#059669': '#34d399',
                '#d97706': '#fbbf24',
                '#dc2626': '#f87171',
                '#2563eb': '#60a5fa',
                '#0891b2': '#22d3ee'
            };
            return colorMap[hex] || '#a78bfa';
        }
    };

    return {
        Toast: Toast,
        Modal: Modal,
        Screen: ScreenRenderer,
        el: _el,
        svg: _svg
    };
})();
