var ZgTelegram = (function() {
    'use strict';

    var _clients = {};
    var _eventHandlers = {};
    var _connectionStates = {};

    var TelegramClient = (typeof GramJS !== 'undefined' && GramJS.TelegramClient) ? GramJS.TelegramClient : null;
    var StringSession = (typeof GramJS !== 'undefined' && GramJS.StringSession) ? GramJS.StringSession : null;
    var Api = (typeof GramJS !== 'undefined' && GramJS.Api) ? GramJS.Api : null;
    var NewMessage = (typeof GramJS !== 'undefined' && GramJS.NewMessage) ? GramJS.NewMessage : null;
    var computeCheck = (typeof GramJS !== 'undefined' && GramJS.computeCheck) ? GramJS.computeCheck : null;
    if (!computeCheck && typeof GramJS !== 'undefined' && GramJS.password && GramJS.password.computeCheck) {
        computeCheck = GramJS.password.computeCheck;
    }

    var EventBus = {
        _listeners: {},

        on: function(event, callback) {
            if (!this._listeners[event]) {
                this._listeners[event] = [];
            }
            this._listeners[event].push(callback);
        },

        off: function(event, callback) {
            if (!this._listeners[event]) return;
            this._listeners[event] = this._listeners[event].filter(function(cb) {
                return cb !== callback;
            });
        },

        emit: function(event, data) {
            if (!this._listeners[event]) return;
            var listeners = this._listeners[event].slice();
            for (var i = 0; i < listeners.length; i++) {
                try {
                    listeners[i](data);
                } catch (err) {
                    console.error('[ZgTelegram] Ошибка обработчика ' + event + ':', err);
                }
            }
        }
    };

    var ConnectionManager = {

        createClient: function(accountId, apiId, apiHash, sessionString) {
            if (!TelegramClient || !StringSession) {
                console.error('[ZgTelegram] GramJS не загружен');
                return null;
            }

            try {
                var session = new StringSession(sessionString || '');
                var client = new TelegramClient(session, parseInt(apiId), apiHash, {
                    connectionRetries: 5,
                    useWSS: true,
                    baseLogger: {
                        log: function() {},
                        warn: function() { console.warn.apply(console, arguments); },
                        error: function() { console.error.apply(console, arguments); },
                        info: function() {},
                        debug: function() {}
                    }
                });

                _clients[accountId] = client;
                _connectionStates[accountId] = 'created';
                console.log('[ZgTelegram] Клиент создан для аккаунта:', accountId);
                return client;
            } catch (err) {
                console.error('[ZgTelegram] Ошибка создания клиента:', err);
                return null;
            }
        },

        getClient: function(accountId) {
            return _clients[accountId] || null;
        },

        isConnected: function(accountId) {
            return _connectionStates[accountId] === 'connected';
        },

        getState: function(accountId) {
            return _connectionStates[accountId] || 'none';
        },

        setState: function(accountId, state) {
            _connectionStates[accountId] = state;
            EventBus.emit('connectionStateChanged', {
                accountId: accountId,
                state: state
            });
        },

        disconnect: function(accountId) {
            var client = _clients[accountId];
            if (client) {
                try {
                    client.disconnect();
                } catch (err) {
                    console.warn('[ZgTelegram] Ошибка отключения:', err);
                }
                delete _clients[accountId];
                _connectionStates[accountId] = 'disconnected';
                ZgStorage.Accounts.setConnected(accountId, false);
                EventBus.emit('connectionStateChanged', {
                    accountId: accountId,
                    state: 'disconnected'
                });
            }
        },

        disconnectAll: function() {
            var ids = Object.keys(_clients);
            for (var i = 0; i < ids.length; i++) {
                this.disconnect(ids[i]);
            }
        }
    };

    var AuthService = {

        _pendingAuth: null,

        startAuth: function(accountId, apiId, apiHash, callbacks) {
            var client = ConnectionManager.createClient(accountId, apiId, apiHash, '');

            if (!client) {
                callbacks.onError('Не удалось создать клиент Telegram');
                return;
            }

            ConnectionManager.setState(accountId, 'connecting');

            this._pendingAuth = {
                accountId: accountId,
                client: client,
                apiId: apiId,
                apiHash: apiHash,
                callbacks: callbacks,
                phoneCodeHash: null
            };

            client.connect()
                .then(function() {
                    ConnectionManager.setState(accountId, 'connected_auth');
                    console.log('[ZgTelegram] Подключен, ожидание номера телефона');
                    callbacks.onConnected();
                })
                .catch(function(err) {
                    ConnectionManager.setState(accountId, 'error');
                    console.error('[ZgTelegram] Ошибка подключения:', err);
                    callbacks.onError('Ошибка подключения: ' + (err.message || err));
                });
        },

        sendCode: function(phoneNumber, callback) {
            if (!this._pendingAuth) {
                callback({ success: false, error: 'Нет активной авторизации' });
                return;
            }

            var client = this._pendingAuth.client;
            var self = this;

            client.invoke(new Api.auth.SendCode({
                phoneNumber: phoneNumber,
                apiId: parseInt(this._pendingAuth.apiId),
                apiHash: this._pendingAuth.apiHash,
                settings: new Api.CodeSettings({
                    allowFlashcall: false,
                    currentNumber: false,
                    allowAppHash: false,
                    allowMissedCall: false,
                    allowFirebase: false
                })
            }))
            .then(function(result) {
                self._pendingAuth.phoneCodeHash = result.phoneCodeHash;
                self._pendingAuth.phone = phoneNumber;
                console.log('[ZgTelegram] Код отправлен');
                callback({ success: true, phoneCodeHash: result.phoneCodeHash });
            })
            .catch(function(err) {
                console.error('[ZgTelegram] Ошибка отправки кода:', err);
                var errorMsg = self._parseError(err);
                callback({ success: false, error: errorMsg });
            });
        },

        signIn: function(code, callback) {
            if (!this._pendingAuth || !this._pendingAuth.phoneCodeHash) {
                callback({ success: false, error: 'Нет хэша кода' });
                return;
            }

            var client = this._pendingAuth.client;
            var self = this;

            client.invoke(new Api.auth.SignIn({
                phoneNumber: this._pendingAuth.phone,
                phoneCodeHash: this._pendingAuth.phoneCodeHash,
                phoneCode: code
            }))
            .then(function(result) {
                if (result instanceof Api.auth.AuthorizationSignUpRequired) {
                    callback({ success: false, error: 'Требуется регистрация', needsSignUp: true });
                    return;
                }
                self._completeAuth(callback);
            })
            .catch(function(err) {
                if (err.errorMessage === 'SESSION_PASSWORD_NEEDED') {
                    callback({ success: false, needsPassword: true, error: 'Требуется пароль 2FA' });
                    return;
                }
                console.error('[ZgTelegram] Ошибка входа:', err);
                var errorMsg = self._parseError(err);
                callback({ success: false, error: errorMsg });
            });
        },

        signInWithPassword: function(password, callback) {
            if (!this._pendingAuth) {
                callback({ success: false, error: 'Нет активной авторизации' });
                return;
            }

            var client = this._pendingAuth.client;
            var self = this;

            client.invoke(new Api.account.GetPassword())
                .then(function(passwordInfo) {
                    if (computeCheck) {
                        return computeCheck(passwordInfo, password)
                            .then(function(srpResult) {
                                return client.invoke(new Api.auth.CheckPassword({
                                    password: srpResult
                                }));
                            });
                    }

                    if (typeof client._checkPassword === 'function') {
                        return client._checkPassword(passwordInfo, password);
                    }

                    if (typeof client.checkPassword === 'function') {
                        return client.checkPassword(passwordInfo, password);
                    }

                    try {
                        var algo = passwordInfo.currentAlgo;
                        if (algo && typeof algo.computeCheck === 'function') {
                            return algo.computeCheck(password)
                                .then(function(srpResult) {
                                    return client.invoke(new Api.auth.CheckPassword({
                                        password: srpResult
                                    }));
                                });
                        }
                    } catch (e) {
                        console.warn('[ZgTelegram] Fallback password method failed:', e);
                    }

                    return client.signInWithPassword(
                        { apiId: parseInt(self._pendingAuth.apiId), apiHash: self._pendingAuth.apiHash },
                        { password: function() { return password; } }
                    );
                })
                .then(function() {
                    self._completeAuth(callback);
                })
                .catch(function(err) {
                    console.error('[ZgTelegram] Ошибка пароля:', err);
                    var errorMsg = self._parseError(err);
                    callback({ success: false, error: errorMsg });
                });
        },

        _completeAuth: function(callback) {
            var self = this;
            var client = this._pendingAuth.client;
            var accountId = this._pendingAuth.accountId;

            client.getMe()
                .then(function(me) {
                    var sessionString = '';
                    try {
                        sessionString = client.session.save();
                    } catch (e) {
                        console.warn('[ZgTelegram] Не удалось сохранить сессию:', e);
                    }

                    var userData = {
                        firstName: me.firstName || '',
                        lastName: me.lastName || '',
                        username: me.username || '',
                        phone: me.phone || self._pendingAuth.phone || '',
                        sessionString: sessionString
                    };

                    ZgStorage.Accounts.update(accountId, {
                        firstName: userData.firstName,
                        lastName: userData.lastName,
                        username: userData.username,
                        phone: userData.phone,
                        sessionString: sessionString,
                        isConnected: true
                    });

                    ConnectionManager.setState(accountId, 'connected');
                    self._pendingAuth = null;

                    EventBus.emit('authCompleted', {
                        accountId: accountId,
                        user: userData
                    });

                    PhotoService.downloadProfilePhoto(accountId);

                    callback({ success: true, user: userData });
                })
                .catch(function(err) {
                    console.error('[ZgTelegram] Ошибка получения профиля:', err);
                    callback({ success: false, error: 'Ошибка получения профиля' });
                });
        },

        cancelAuth: function() {
            if (this._pendingAuth) {
                var accountId = this._pendingAuth.accountId;
                ConnectionManager.disconnect(accountId);
                this._pendingAuth = null;
            }
        },

        _parseError: function(err) {
            var msg = err.errorMessage || err.message || 'Неизвестная ошибка';
            var errorMap = {
                'PHONE_NUMBER_INVALID': 'Неверный номер телефона',
                'PHONE_CODE_INVALID': 'Неверный код',
                'PHONE_CODE_EXPIRED': 'Код истёк, запросите новый',
                'PASSWORD_HASH_INVALID': 'Неверный пароль',
                'PHONE_NUMBER_BANNED': 'Номер заблокирован',
                'PHONE_NUMBER_FLOOD': 'Слишком много попыток, подождите',
                'API_ID_INVALID': 'Неверный API ID',
                'SESSION_PASSWORD_NEEDED': 'Требуется двухфакторная аутентификация',
                'FLOOD_WAIT': 'Подождите перед повторной попыткой',
                'AUTH_KEY_UNREGISTERED': 'Сессия истекла'
            };

            for (var key in errorMap) {
                if (msg.indexOf(key) !== -1) {
                    if (key === 'FLOOD_WAIT') {
                        var seconds = msg.match(/\d+/);
                        if (seconds) {
                            return 'Подождите ' + seconds[0] + ' секунд';
                        }
                    }
                    return errorMap[key];
                }
            }
            return msg;
        }
    };

    var ChatService = {

        getDialogs: function(accountId, options, callback) {
            var client = ConnectionManager.getClient(accountId);
            if (!client) {
                callback({ success: false, error: 'Клиент не найден' });
                return;
            }

            var limit = (options && options.limit) ? options.limit : 30;
            var offsetDate = (options && options.offsetDate) ? options.offsetDate : 0;

            client.invoke(new Api.messages.GetDialogs({
                offsetDate: offsetDate,
                offsetId: 0,
                offsetPeer: new Api.InputPeerEmpty(),
                limit: limit,
                hash: BigInt(0)
            }))
            .then(function(result) {
                var dialogs = ChatService._processDialogs(result);
                callback({ success: true, dialogs: dialogs });
            })
            .catch(function(err) {
                console.error('[ZgTelegram] Ошибка загрузки чатов:', err);
                callback({ success: false, error: err.message || 'Ошибка загрузки чатов' });
            });
        },

        getMessages: function(accountId, peerId, options, callback) {
            var client = ConnectionManager.getClient(accountId);
            if (!client) {
                callback({ success: false, error: 'Клиент не найден' });
                return;
            }

            var limit = (options && options.limit) ? options.limit : 50;
            var offsetId = (options && options.offsetId) ? options.offsetId : 0;

            client.invoke(new Api.messages.GetHistory({
                peer: peerId,
                offsetId: offsetId,
                offsetDate: 0,
                addOffset: 0,
                limit: limit,
                maxId: 0,
                minId: 0,
                hash: BigInt(0)
            }))
            .then(function(result) {
                var messages = [];
                if (result.messages) {
                    for (var i = 0; i < result.messages.length; i++) {
                        var msg = result.messages[i];
                        messages.push({
                            id: msg.id,
                            text: msg.message || '',
                            date: msg.date,
                            out: msg.out || false,
                            fromId: msg.fromId ? (msg.fromId.userId || msg.fromId.channelId || null) : null,
                            replyToMsgId: msg.replyTo ? msg.replyTo.replyToMsgId : null,
                            media: msg.media ? true : false,
                            edited: msg.editDate ? true : false
                        });
                    }
                }
                callback({ success: true, messages: messages.reverse() });
            })
            .catch(function(err) {
                console.error('[ZgTelegram] Ошибка загрузки сообщений:', err);
                callback({ success: false, error: err.message || 'Ошибка загрузки сообщений' });
            });
        },

        sendMessage: function(accountId, peerId, text, callback) {
            var client = ConnectionManager.getClient(accountId);
            if (!client) {
                callback({ success: false, error: 'Клиент не найден' });
                return;
            }

            client.invoke(new Api.messages.SendMessage({
                peer: peerId,
                message: text,
                randomId: BigInt(Math.floor(Math.random() * Number.MAX_SAFE_INTEGER)),
                noWebpage: false,
                silent: false
            }))
            .then(function(result) {
                callback({ success: true, result: result });
            })
            .catch(function(err) {
                console.error('[ZgTelegram] Ошибка отправки:', err);
                callback({ success: false, error: err.message || 'Ошибка отправки' });
            });
        },

        searchDialogs: function(accountId, query, callback) {
            var client = ConnectionManager.getClient(accountId);
            if (!client) {
                callback({ success: false, error: 'Клиент не найден' });
                return;
            }

            client.invoke(new Api.contacts.Search({
                q: query,
                limit: 20
            }))
            .then(function(result) {
                var results = [];
                if (result.users) {
                    for (var u = 0; u < result.users.length; u++) {
                        var user = result.users[u];
                        results.push({
                            type: user.bot ? 'bot' : 'user',
                            id: user.id,
                            title: ((user.firstName || '') + ' ' + (user.lastName || '')).trim(),
                            username: user.username || '',
                            online: user.status && user.status.className === 'UserStatusOnline',
                            bot: user.bot || false,
                            letter: (user.firstName || user.username || '?').charAt(0).toUpperCase()
                        });
                    }
                }
                if (result.chats) {
                    for (var c = 0; c < result.chats.length; c++) {
                        var chat = result.chats[c];
                        results.push({
                            type: chat.broadcast ? 'channel' : (chat.megagroup ? 'supergroup' : 'chat'),
                            id: chat.id,
                            title: chat.title || '',
                            username: chat.username || '',
                            online: false,
                            bot: false,
                            letter: (chat.title || '?').charAt(0).toUpperCase()
                        });
                    }
                }
                callback({ success: true, results: results });
            })
            .catch(function(err) {
                console.error('[ZgTelegram] Ошибка поиска:', err);
                callback({ success: false, error: err.message || 'Ошибка поиска' });
            });
        },

        _processDialogs: function(result) {
            var dialogs = [];
            var users = {};
            var chats = {};

            if (result.users) {
                for (var u = 0; u < result.users.length; u++) {
                    var user = result.users[u];
                    users[user.id] = {
                        id: user.id,
                        firstName: user.firstName || '',
                        lastName: user.lastName || '',
                        username: user.username || '',
                        online: user.status && user.status.className === 'UserStatusOnline',
                        bot: user.bot || false,
                        photo: user.photo || null
                    };
                }
            }

            if (result.chats) {
                for (var c = 0; c < result.chats.length; c++) {
                    var chat = result.chats[c];
                    chats[chat.id] = {
                        id: chat.id,
                        title: chat.title || '',
                        megagroup: chat.megagroup || false,
                        broadcast: chat.broadcast || false,
                        participantsCount: chat.participantsCount || 0,
                        photo: chat.photo || null
                    };
                }
            }

            if (result.dialogs) {
                for (var d = 0; d < result.dialogs.length; d++) {
                    var dialog = result.dialogs[d];
                    var peer = dialog.peer;
                    var dialogData = {
                        unreadCount: dialog.unreadCount || 0,
                        topMessage: dialog.topMessage || 0,
                        pinned: dialog.pinned || false,
                        readInboxMaxId: dialog.readInboxMaxId || 0,
                        readOutboxMaxId: dialog.readOutboxMaxId || 0
                    };

                    if (peer.userId) {
                        var userData = users[peer.userId];
                        if (userData) {
                            dialogData.type = 'user';
                            dialogData.id = peer.userId;
                            dialogData.title = (userData.firstName + ' ' + userData.lastName).trim();
                            dialogData.username = userData.username;
                            dialogData.online = userData.online;
                            dialogData.bot = userData.bot;
                        }
                    } else if (peer.chatId) {
                        var chatData = chats[peer.chatId];
                        if (chatData) {
                            dialogData.type = 'chat';
                            dialogData.id = peer.chatId;
                            dialogData.title = chatData.title;
                        }
                    } else if (peer.channelId) {
                        var channelData = chats[peer.channelId];
                        if (channelData) {
                            dialogData.type = channelData.broadcast ? 'channel' : 'supergroup';
                            dialogData.id = peer.channelId;
                            dialogData.title = channelData.title;
                        }
                    }

                    var topMsg = null;
                    if (result.messages) {
                        for (var m = 0; m < result.messages.length; m++) {
                            if (result.messages[m].id === dialog.topMessage) {
                                topMsg = result.messages[m];
                                break;
                            }
                        }
                    }

                    if (topMsg) {
                        dialogData.lastMessage = {
                            text: topMsg.message || '',
                            date: topMsg.date,
                            out: topMsg.out || false,
                            media: topMsg.media ? true : false
                        };
                    }

                    dialogData.letter = dialogData.title ? dialogData.title.charAt(0).toUpperCase() : '?';

                    dialogs.push(dialogData);
                }
            }

            return dialogs;
        }
    };

    var PhotoService = {

        _photoCache: {},

        downloadProfilePhoto: function(accountId, callback) {
            var client = ConnectionManager.getClient(accountId);
            if (!client) {
                if (callback) callback(null);
                return;
            }

            var cacheKey = 'avatar_' + accountId;
            var cached = ZgStorage.Cache.get(cacheKey);
            if (cached) {
                this._photoCache[accountId] = cached;
                if (callback) callback(cached);
                return;
            }

            var self = this;

            client.downloadProfilePhoto('me', { isBig: false })
                .then(function(buffer) {
                    if (buffer && buffer.length > 0) {
                        var bytes = buffer instanceof ArrayBuffer ? new Uint8Array(buffer) : (buffer instanceof Uint8Array ? buffer : new Uint8Array(buffer));
                        var binary = '';
                        var chunkSize = 8192;
                        for (var i = 0; i < bytes.length; i += chunkSize) {
                            var chunk = bytes.subarray(i, Math.min(i + chunkSize, bytes.length));
                            binary += String.fromCharCode.apply(null, chunk);
                        }
                        var dataUrl = 'data:image/jpeg;base64,' + btoa(binary);
                        self._photoCache[accountId] = dataUrl;
                        ZgStorage.Cache.set(cacheKey, dataUrl, 24 * 60 * 60 * 1000);
                        ZgStorage.Accounts.update(accountId, { photoUrl: dataUrl });
                        if (callback) callback(dataUrl);
                    } else {
                        if (callback) callback(null);
                    }
                })
                .catch(function(err) {
                    console.warn('[ZgTelegram] Ошибка загрузки аватара:', err);
                    if (callback) callback(null);
                });
        },

        getPhotoUrl: function(accountId) {
            if (this._photoCache[accountId]) {
                return this._photoCache[accountId];
            }
            var cached = ZgStorage.Cache.get('avatar_' + accountId);
            if (cached) {
                this._photoCache[accountId] = cached;
                return cached;
            }
            var account = ZgStorage.Accounts.getById(accountId);
            if (account && account.photoUrl) {
                return account.photoUrl;
            }
            return null;
        },

        downloadChatPhoto: function(accountId, peerId, peerType, callback) {
            var client = ConnectionManager.getClient(accountId);
            if (!client) {
                if (callback) callback(null);
                return;
            }

            var cacheKey = 'chat_avatar_' + peerId;
            var cached = ZgStorage.Cache.get(cacheKey);
            if (cached) {
                if (callback) callback(cached);
                return;
            }

            var self = this;

            var inputPeer;
            try {
                if (peerType === 'user') {
                    inputPeer = new Api.InputPeerUser({ userId: peerId, accessHash: BigInt(0) });
                } else if (peerType === 'channel' || peerType === 'supergroup') {
                    inputPeer = new Api.InputPeerChannel({ channelId: peerId, accessHash: BigInt(0) });
                } else {
                    inputPeer = new Api.InputPeerChat({ chatId: peerId });
                }
            } catch (e) {
                if (callback) callback(null);
                return;
            }

            client.downloadProfilePhoto(inputPeer, { isBig: false })
                .then(function(buffer) {
                    if (buffer && buffer.length > 0) {
                        var bytes = buffer instanceof ArrayBuffer ? new Uint8Array(buffer) : (buffer instanceof Uint8Array ? buffer : new Uint8Array(buffer));
                        var binary = '';
                        var chunkSize = 8192;
                        for (var i = 0; i < bytes.length; i += chunkSize) {
                            var chunk = bytes.subarray(i, Math.min(i + chunkSize, bytes.length));
                            binary += String.fromCharCode.apply(null, chunk);
                        }
                        var dataUrl = 'data:image/jpeg;base64,' + btoa(binary);
                        ZgStorage.Cache.set(cacheKey, dataUrl, 12 * 60 * 60 * 1000);
                        if (callback) callback(dataUrl);
                    } else {
                        if (callback) callback(null);
                    }
                })
                .catch(function(err) {
                    console.warn('[ZgTelegram] Ошибка загрузки аватара чата:', err);
                    if (callback) callback(null);
                });
        }
    };

    var SessionManager = {

        restoreSession: function(accountId, callback) {
            var account = ZgStorage.Accounts.getById(accountId);
            if (!account || !account.sessionString) {
                callback({ success: false, error: 'Нет сохранённой сессии' });
                return;
            }

            var client = ConnectionManager.createClient(
                accountId,
                account.apiId,
                account.apiHash,
                account.sessionString
            );

            if (!client) {
                callback({ success: false, error: 'Не удалось создать клиент' });
                return;
            }

            ConnectionManager.setState(accountId, 'restoring');

            client.connect()
                .then(function() {
                    return client.getMe();
                })
                .then(function(me) {
                    ConnectionManager.setState(accountId, 'connected');
                    ZgStorage.Accounts.setConnected(accountId, true);

                    ZgStorage.Accounts.update(accountId, {
                        firstName: me.firstName || '',
                        lastName: me.lastName || '',
                        username: me.username || ''
                    });

                    try {
                        var newSessionString = client.session.save();
                        ZgStorage.Accounts.updateSession(accountId, newSessionString);
                    } catch (e) {
                        console.warn('[ZgTelegram] Не удалось обновить сессию:', e);
                    }

                    PhotoService.downloadProfilePhoto(accountId);

                    console.log('[ZgTelegram] Сессия восстановлена для:', accountId);
                    callback({ success: true });
                })
                .catch(function(err) {
                    ConnectionManager.setState(accountId, 'error');
                    console.error('[ZgTelegram] Ошибка восстановления сессии:', err);
                    callback({ success: false, error: err.message || 'Ошибка восстановления' });
                });
        },

        restoreAllSessions: function(callback) {
            var accounts = ZgStorage.Accounts.getAll();
            var totalAccounts = accounts.length;
            var completedCount = 0;
            var results = [];

            if (totalAccounts === 0) {
                callback({ success: true, results: [] });
                return;
            }

            for (var i = 0; i < accounts.length; i++) {
                (function(account) {
                    if (account.sessionString) {
                        SessionManager.restoreSession(account.id, function(result) {
                            completedCount++;
                            results.push({
                                accountId: account.id,
                                success: result.success,
                                error: result.error || null
                            });

                            if (completedCount >= totalAccounts) {
                                callback({ success: true, results: results });
                            }
                        });
                    } else {
                        completedCount++;
                        results.push({
                            accountId: account.id,
                            success: false,
                            error: 'Нет сессии'
                        });
                        if (completedCount >= totalAccounts) {
                            callback({ success: true, results: results });
                        }
                    }
                })(accounts[i]);
            }
        }
    };

    var NotificationService = {

        _serviceWorkerRegistered: false,

        init: function() {
            if ('Notification' in window) {
                if (Notification.permission === 'default') {
                    Notification.requestPermission();
                }
            }
        },

        shouldNotify: function(accountId) {
            var globalEnabled = ZgStorage.Settings.get('notificationsGlobal');
            if (!globalEnabled) {
                return false;
            }
            return ZgStorage.Accounts.getNotificationStatus(accountId);
        },

        showNotification: function(accountId, title, body, data) {
            if (!this.shouldNotify(accountId)) {
                return;
            }

            if ('Notification' in window && Notification.permission === 'granted') {
                try {
                    var notification = new Notification(title, {
                        body: body,
                        icon: 'data:image/svg+xml,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" rx="16" fill="#7c3aed"/><text x="32" y="42" text-anchor="middle" fill="white" font-size="28" font-weight="bold" font-family="monospace">ZG</text></svg>'),
                        badge: 'data:image/svg+xml,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" rx="16" fill="#7c3aed"/></svg>'),
                        tag: 'zg_' + accountId + '_' + (data ? data.chatId : ''),
                        silent: false,
                        data: data
                    });

                    notification.onclick = function() {
                        window.focus();
                        if (data && data.chatId) {
                            window.location.hash = '#chat/' + data.chatId;
                        }
                        notification.close();
                    };

                    setTimeout(function() {
                        notification.close();
                    }, 8000);
                } catch (err) {
                    console.warn('[ZgTelegram] Ошибка уведомления:', err);
                }
            }
        }
    };

    return {
        Connection: ConnectionManager,
        Auth: AuthService,
        Chat: ChatService,
        Photo: PhotoService,
        Session: SessionManager,
        Notifications: NotificationService,
        Events: EventBus,
        isGramJSLoaded: function() {
            return TelegramClient !== null && StringSession !== null && Api !== null;
        }
    };
})();
